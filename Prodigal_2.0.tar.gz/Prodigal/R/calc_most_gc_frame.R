calc_most_gc_frame <- function(sequence) {

  # From Prodigal sequence.c: "Creates a GC frame plot for a given sequence.
  #   This is simply a string with the highest GC content frame for a window
  #   centered on position for every position in the sequence."

  WINDOW <- 120   # Size of window for determining GC content - needs to be a factor of 6
                  # The actual window size is one base smaller.

  # Strings to pad the beginning and end of the sequence with non-GC bases
  beg <- DNAString(paste(replicate(WINDOW/6-1, "N"), collapse = ""))
  end <- DNAString(paste(replicate(WINDOW/6-1, "N"), collapse = ""))

  frame1 <- xscat(beg, sequence[seq(1, length(sequence), 3)], end)
  frame2 <- xscat(beg, sequence[seq(2, length(sequence), 3)], end)
  frame3 <- xscat(beg, sequence[seq(3, length(sequence), 3)], end)

  gc1 <- rowSums(letterFrequencyInSlidingView(frame1, WINDOW/3-1, c("G","C")));
  gc2 <- rowSums(letterFrequencyInSlidingView(frame2, WINDOW/3-1, c("G","C")));
  gc3 <- rowSums(letterFrequencyInSlidingView(frame3, WINDOW/3-1, c("G","C")));

  # gc1 will have the greatest length; gc2 and gc3 will be no more than one element shorter
  len1 <- length(gc1)
  len2 <- length(gc2)
  len3 <- length(gc3)

  if ( len2 < len1 ) { gc2 <- c(gc2, -1) }
  if ( len3 < len1 ) { gc3 <- c(gc3, -1) }


  # Create a data frame for the three DNA frames
  all_frames <- data.frame(gc1, gc2, gc3)

  # For each position in the sequence, determine the frame with the highest GC content within the window
  gc_frame <- max_gc_frame(all_frames)

  return (gc_frame)
}
