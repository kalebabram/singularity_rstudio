prodigal<-function(parameter, short = FALSE) {

  cat ("Request: Single Genome, Phase: Training\n")

  # The code in this function (up to Point A) differs significantly from the original C implementation,
  #   which uses a bit-string to encode the genomic sequence.

  # We do NOT want string in dataframes to be factors

  options(stringsAsFactors = FALSE)

  # Check the class of the parameter
  # It must be a DNAString, a DNAStringSet, or a character, which is assumed to be the name of a FASTA file

  if (class(parameter) == "DNAString") {
    Sequences <- DNAStringSet(parameter)   # A single DNAString becomes a DNAStringSet of length 1
  }

  else if (class(parameter) == "DNAStringSet") {
    Sequences <- parameter
  }

  else if (class(parameter) == "character") {
    Sequences <- readDNAStringSet(parameter, format = 'fasta')
  }

  else {
    stop ("prodigal parameter must be either a DNAString, a DNAStringSet, or the name of a FASTA file\n")
  }

  cat ("Reading in the sequence(s) to train ... ")

  sequence <- as.character(Sequences[[1]])

  # If we encounter multiple sequences, we insert TTAATTAATTAA between each one to force stops in all six frames ...

  numSeq <- length(Sequences)

  if (numSeq > 1) {

    spacer <- "TTAATTAATTAA"

    for (seqNum in 2:numSeq) {
      sequence <- paste0(sequence, spacer)
      sequence <- paste0(sequence, as.character(Sequences[[seqNum]]))
    }

    # ... AND we insert TTAATTAATTAA after the final sequence to be consistent with the Prodigal C implementation
    sequence <- paste0(sequence, spacer)

  }

  sequence <- DNAString(sequence)
  reverse <- reverseComplement(sequence)

  seq_len = length(sequence)

  cat (seq_len, "bp sequence created, ")


  # Set up the TRAINING structure as an R list

  training <- list(
    gc          = numeric(1),
    trans_table = integer(1),
    st_wt       = numeric(1),
    bias        = numeric(3),
    type_wt     = numeric(3),
    uses_sd     = integer(1),
    rbs_wt      = numeric(28),
    ups_comp    = matrix(NA,32,4),
    mot_wt      = array(NA,dim=c(4,4,4096)),
    no_mot      = numeric(1),
    gene_dc     = numeric(4096)
  )

  # From the Prodigal C implementation:
  #   Set the start score weight.  Changing this number can dramatically affect the performance of the program.
  #   Some genomes want it high (6+), and some prefer it low (2.5-3).  Attempts were made to determine this weight
  #   dynamically, but none were successful.  Therefore, we just manually set the weight to an average value that
  #   seems to work decently for 99% of genomes.  This problem may be revisited in future versions.

  training$st_wt = 4.35;

  # This initial implementation of R Prodigal assumes that we are working with the finished genome sequence
  # of a microbe that uses the Bacterial, Archaeal, and Plant Plastid Code, translation table 11.

  training$trans_table = 11;

  # Compute GC content

  training$gc <- as.double(letterFrequency(sequence,"GC") / seq_len)

  cat (paste0(signif(training$gc * 100, digits = 4), "% GC\n"))



  # Build the NODE structure incrementally as an R data frame

  Nodes.df <- data.frame(index=integer(), type=character(), strand=character(), stop_val=integer(), edge=logical(), stringsAsFactors=FALSE)

  # Find the potential STARTs and STOPs in the forward frames

  for (frame in c(1,2,0)) {   # Order equivalent to (1,2,3) modulo 3
                              # Order in which the frames are examined is not important

    Coords.df <- data.frame(locate=integer(), pattrn=character(), stringsAsFactors=FALSE)

    for (NNN in c("ATG","GTG","TTG")) {
      vector <- matchPattern(NNN, sequence)
      coords <- start(vector)
      locate <- coords[(coords %% 3) == frame]
      pattrn <- rep(NNN, length(locate))
      Coords.df <- rbind(Coords.df, data.frame(locate, pattrn, stringsAsFactors=FALSE))
    }

    for (NNN in c("TAG","TGA","TAA")) {
      vector <- matchPattern(NNN, sequence)
      coords <- start(vector)
      locate <- coords[(coords %% 3) == frame]
      pattrn <- rep("STOP", length(locate))
      Coords.df <- rbind(Coords.df, data.frame(locate, pattrn, stringsAsFactors=FALSE))
    }

    # Add dummy STOPS and STARTS for potential edge nodes

    pattrn <- c("STOP","ATG","STOP")
    if (frame == 1) { locate <- c(-5,1,seq_len-(seq_len%%3-frame)%%3) }
    if (frame == 2) { locate <- c(-4,2,seq_len-(seq_len%%3-frame)%%3) }
    if (frame == 0) { locate <- c(-3,3,seq_len-(seq_len%%3-frame)%%3) }

    # Final STOP goes into last complete codon in the appropriate frame
    if (frame == 1) { locate <- c(-5,1,seq_len-2-((seq_len-2)%%3-frame)%%3) }
    if (frame == 2) { locate <- c(-4,2,seq_len-2-((seq_len-2)%%3-frame)%%3) }
    if (frame == 0) { locate <- c(-3,3,seq_len-2-((seq_len-2)%%3-frame)%%3) }

    Coords.df <- rbind(data.frame(locate, pattrn, stringsAsFactors=FALSE), Coords.df)

    # Sort the lists by location
    Coords.df <- Coords.df[order(Coords.df$locate),]

    Nodes.df <- rbind(Nodes.df, coord2node(Coords.df, seq_len, 1))    # 1 indicates forward strand
  }


  # Find the potential STARTs and STOPs in the reverse frames

  for (frame in c(1,2,0)) {   # Order equivalent to (1,2,3) modulo 3
                              # Order in which the frames are examined is not important

    Coords.df <- data.frame(locate=integer(), pattrn=character(), stringsAsFactors=FALSE)

    for (NNN in c("ATG","GTG","TTG")) {
      vector <- matchPattern(NNN, reverse)
      coords <- start(vector)
      locate <- coords[(coords %% 3) == frame]
      pattrn <- rep(NNN, length(locate))
      Coords.df <- rbind(Coords.df, data.frame(locate, pattrn, stringsAsFactors=FALSE))
    }

    for (NNN in c("TAG","TGA","TAA")) {
      vector <- matchPattern(NNN, reverse)
      coords <- start(vector)
      locate <- coords[(coords %% 3) == frame]
      pattrn <- rep("STOP", length(locate))
      Coords.df <- rbind(Coords.df, data.frame(locate, pattrn, stringsAsFactors=FALSE))
    }

    # Add dummy STOPS and STARTS for potential edge nodes

    pattrn <- c("STOP","ATG","STOP")
    if (frame == 1) { locate <- c(-5,1,seq_len-(seq_len%%3-frame)%%3) }
    if (frame == 2) { locate <- c(-4,2,seq_len-(seq_len%%3-frame)%%3) }
    if (frame == 0) { locate <- c(-3,3,seq_len-(seq_len%%3-frame)%%3) }

    # Final STOP goes into last complete codon in the appropriate frame
    if (frame == 1) { locate <- c(-5,1,seq_len-2-((seq_len-2)%%3-frame)%%3) }
    if (frame == 2) { locate <- c(-4,2,seq_len-2-((seq_len-2)%%3-frame)%%3) }
    if (frame == 0) { locate <- c(-3,3,seq_len-2-((seq_len-2)%%3-frame)%%3) }

    Coords.df <- rbind(data.frame(locate, pattrn, stringsAsFactors=FALSE), Coords.df)

    # Sort the lists by location
    Coords.df <- Coords.df[order(Coords.df$locate),]

    Nodes.df <- rbind(Nodes.df, coord2node(Coords.df, seq_len, -1))    # -1 indicates reverse strand
  }


  # Sort the nodes:

  Nodes.df <- Nodes.df[order(Nodes.df$ndx, -rank(Nodes.df$strand)),]
  Nodes.df <- Nodes.df[!duplicated(Nodes.df),]

  # Uncomment to return Node dataframe for debugging
  # return(Nodes.df)

  # Point A - see comments at the beginning of this file.

  # We now know the total number of nodes so add all remaining columns to the nodes dataframe

  Nodes.df$star_ptr_1     <- 0     # Array of starts within MAX_SAM_OVLP bases of a stop in three frames
  Nodes.df$star_ptr_2     <- 0 
  Nodes.df$star_ptr_3     <- 0 
  Nodes.df$gc_bias        <- 0     # Frame of highest GC content within this node
  Nodes.df$gc_score_1     <- 0.0   # Array of %GC content in different codon positions
  Nodes.df$gc_score_2     <- 0.0 
  Nodes.df$gc_score_3     <- 0.0 
  Nodes.df$cscore         <- 0.0   # Coding score for this node (based on 6-mer usage)
  Nodes.df$gc_cont        <- 0.0   # GC content for this node
  Nodes.df$rbs_1          <- 0     # Shine-Dalgarno RBS score for this node ... best motif with exact match
  Nodes.df$rbs_2          <- 0     #                                        ... best motif with mismatchs
  Nodes.df$motif_ndx      <- 0     # Index of the best motif for this node
  Nodes.df$motif_len      <- 0     # Length of the motif
  Nodes.df$motif_spacer   <- 0     # Spacer between coding start and the motif
  Nodes.df$motif_spacendx <- 0     # Index for this spacer length
  Nodes.df$motif_score    <- 0.0   # Score for the motif
  Nodes.df$uscore         <- 0.0   # Score for the upstream -1/-2, -15 to -45 region
  Nodes.df$tscore         <- 0.0   # Score for the ATG/GTG/TTG value
  Nodes.df$rscore         <- 0.0   # Score for the RBS motif
  Nodes.df$sscore         <- 0.0   # Score for the strength of the start codon
  Nodes.df$traceb         <- -1    # Traceback to connecting node
  Nodes.df$tracef         <- -1    # Trace to forward node
  Nodes.df$ov_mark        <- -1    # Marker to help untangle overlapping genes
  Nodes.df$score          <- 0.0   # Score of total solution to this point
  Nodes.df$elim           <- FALSE # If TRUE, eliminate this gene from the model

  # Scan all the ORFS looking for a potential GC bias in a particular codon position.
  # This information will be used to acquire a good initial set of genes.

  gc_frame <- calc_most_gc_frame(sequence)

  # At this point, we expect all further modifications to the nodes to be made in a C/C++ environment,
  #   so we shift the node values that are node indices from a 1-based to a 0-based coordinate system.

  Nodes.df$ndx      <- Nodes.df$ndx      - 1
  Nodes.df$stop_val <- Nodes.df$stop_val - 1

  # Note: The Prodigal C function record_gc_bias has been split
  #   to update the NODE structure and the TRAINING structure separately

  Nodes.df <- as.data.frame(record_gc_bias_node(gc_frame, Nodes.df))
  training$bias <- as.vector(record_gc_bias_training(Nodes.df, training))

  cat ("Looking for GC bias in different frames ... frame bias scores:",
    signif(training$bias[1], digits = 3),
    signif(training$bias[2], digits = 3),
    signif(training$bias[3], digits = 3),
    "\n"
  )


  # Do an initial dynamic programming routine with just the GC frame bias used as a scoring function.
  # This will get an initial set of genes to train on.

  # Note: This function has been moved to the do_training routine
  # Nodes.df <- as.data.frame(record_overlapping_starts(Nodes.df, training, 0))

  training <- as.list(do_training(Nodes.df, training, as.character(sequence), as.character(reverse)))

  # Redimension the mot_wt member -- which started life as a 3-D array but was unpacked into a 1-D array
  # as it passed through an Rcpp data type

  dim(training$mot_wt) <- c(4,4,4096)

  # Uncomment to return training structure for debugging
  # return(training)

  # Precaution: Save the training structure to be used for each sequence

  training_global <- training



  #---------------------------
  # LOOP over set of sequences
  #---------------------------

  ## Note: There's a lot of repeated code here. Could be made more compact, but probably not more efficient.

  cat ("---------------------\n")
  cat ("Request: Single Genome, Phase: Gene Finding\n")

  allGenes.df <- data.frame()
  offset <- 0

  for (seqNum in 1:numSeq) {

    training <- training_global

    sequence <- Sequences[[seqNum]]
    reverse <- reverseComplement(sequence)

    seq_len = length(sequence)

    cat (paste0("Finding genes in sequence # ", seqNum, " (", seq_len, " bp) ... "))

    # Build the NODE structure incrementally as an R data frame

    Nodes.df <- data.frame(index=integer(), type=character(), strand=character(), stop_val=integer(), edge=logical(), stringsAsFactors=FALSE)

    # Find the potential STARTs and STOPs in the forward frames

    for (frame in c(1,2,0)) {   # Order equivalent to (1,2,3) modulo 3 
                                # Order in which the frames are examined is not important

      Coords.df <- data.frame(locate=integer(), pattrn=character(), stringsAsFactors=FALSE)

      for (NNN in c("ATG","GTG","TTG")) {
        vector <- matchPattern(NNN, sequence)
        coords <- start(vector)
        locate <- coords[(coords %% 3) == frame]
        pattrn <- rep(NNN, length(locate))
        Coords.df <- rbind(Coords.df, data.frame(locate, pattrn, stringsAsFactors=FALSE))
      }

      for (NNN in c("TAG","TGA","TAA")) {
        vector <- matchPattern(NNN, sequence)
        coords <- start(vector)
        locate <- coords[(coords %% 3) == frame]
        pattrn <- rep("STOP", length(locate))
        Coords.df <- rbind(Coords.df, data.frame(locate, pattrn, stringsAsFactors=FALSE))
      }

      # Add dummy STOPS and STARTS for potential edge nodes

      pattrn <- c("STOP","ATG","STOP")
      if (frame == 1) { locate <- c(-5,1,seq_len-(seq_len%%3-frame)%%3) }
      if (frame == 2) { locate <- c(-4,2,seq_len-(seq_len%%3-frame)%%3) }
      if (frame == 0) { locate <- c(-3,3,seq_len-(seq_len%%3-frame)%%3) }

      # Final STOP goes into last complete codon in the appropriate frame
      if (frame == 1) { locate <- c(-5,1,seq_len-2-((seq_len-2)%%3-frame)%%3) }
      if (frame == 2) { locate <- c(-4,2,seq_len-2-((seq_len-2)%%3-frame)%%3) }
      if (frame == 0) { locate <- c(-3,3,seq_len-2-((seq_len-2)%%3-frame)%%3) }

      Coords.df <- rbind(data.frame(locate, pattrn, stringsAsFactors=FALSE), Coords.df)

      # Sort the lists by location
      Coords.df <- Coords.df[order(Coords.df$locate),]

      Nodes.df <- rbind(Nodes.df, coord2node(Coords.df, seq_len, 1))    # 1 indicates forward strand
    }


    # Find the potential STARTs and STOPs in the reverse frames

    for (frame in c(1,2,0)) {   # Order equivalent to (1,2,3) modulo 3 
                                # Order in which the frames are examined is not important

      Coords.df <- data.frame(locate=integer(), pattrn=character(), stringsAsFactors=FALSE)

      for (NNN in c("ATG","GTG","TTG")) {
        vector <- matchPattern(NNN, reverse)
        coords <- start(vector)
        locate <- coords[(coords %% 3) == frame]
        pattrn <- rep(NNN, length(locate))
        Coords.df <- rbind(Coords.df, data.frame(locate, pattrn, stringsAsFactors=FALSE))
      }

      for (NNN in c("TAG","TGA","TAA")) {
        vector <- matchPattern(NNN, reverse)
        coords <- start(vector)
        locate <- coords[(coords %% 3) == frame]
        pattrn <- rep("STOP", length(locate))
        Coords.df <- rbind(Coords.df, data.frame(locate, pattrn, stringsAsFactors=FALSE))
      }

      # Add dummy STOPS and STARTS for potential edge nodes

      pattrn <- c("STOP","ATG","STOP")
      if (frame == 1) { locate <- c(-5,1,seq_len-(seq_len%%3-frame)%%3) }
      if (frame == 2) { locate <- c(-4,2,seq_len-(seq_len%%3-frame)%%3) }
      if (frame == 0) { locate <- c(-3,3,seq_len-(seq_len%%3-frame)%%3) }

      # Final STOP goes into last complete codon in the appropriate frame
      if (frame == 1) { locate <- c(-5,1,seq_len-2-((seq_len-2)%%3-frame)%%3) }
      if (frame == 2) { locate <- c(-4,2,seq_len-2-((seq_len-2)%%3-frame)%%3) }
      if (frame == 0) { locate <- c(-3,3,seq_len-2-((seq_len-2)%%3-frame)%%3) }

      Coords.df <- rbind(data.frame(locate, pattrn, stringsAsFactors=FALSE), Coords.df)

      # Sort the lists by location
      Coords.df <- Coords.df[order(Coords.df$locate),]

      Nodes.df <- rbind(Nodes.df, coord2node(Coords.df, seq_len, -1))    # -1 indicates reverse strand
    }

    # Sort the nodes:

    Nodes.df <- Nodes.df[order(Nodes.df$ndx, -rank(Nodes.df$strand)),]

    # Point A - see comments at the beginning of this file.

    # We now know the total number of nodes so add all remaining columns to the nodes dataframe

    Nodes.df$star_ptr_1     <- 0     # Array of starts within MAX_SAM_OVLP bases of a stop in three frames
    Nodes.df$star_ptr_2     <- 0 
    Nodes.df$star_ptr_3     <- 0 
    Nodes.df$gc_bias        <- 0     # Frame of highest GC content within this node
    Nodes.df$gc_score_1     <- 0.0   # Array of %GC content in different codon positions
    Nodes.df$gc_score_2     <- 0.0 
    Nodes.df$gc_score_3     <- 0.0 
    Nodes.df$cscore         <- 0.0   # Coding score for this node (based on 6-mer usage)
    Nodes.df$gc_cont        <- 0.0   # GC content for this node
    Nodes.df$rbs_1          <- 0     # Shine-Dalgarno RBS score for this node ... best motif with exact match
    Nodes.df$rbs_2          <- 0     #                                        ... best motif with mismatchs
    Nodes.df$motif_ndx      <- 0     # Index of the best motif for this node
    Nodes.df$motif_len      <- 0     # Length of the motif
    Nodes.df$motif_spacer   <- 0     # Spacer between coding start and the motif
    Nodes.df$motif_spacendx <- 0     # Index for this spacer length
    Nodes.df$motif_score    <- 0.0   # Score for the motif
    Nodes.df$uscore         <- 0.0   # Score for the upstream -1/-2, -15 to -45 region
    Nodes.df$tscore         <- 0.0   # Score for the ATG/GTG/TTG value
    Nodes.df$rscore         <- 0.0   # Score for the RBS motif
    Nodes.df$sscore         <- 0.0   # Score for the strength of the start codon
    Nodes.df$traceb         <- -1    # Traceback to connecting node
    Nodes.df$tracef         <- -1    # Trace to forward node
    Nodes.df$ov_mark        <- -1    # Marker to help untangle overlapping genes
    Nodes.df$score          <- 0.0   # Score of total solution to this point
    Nodes.df$elim           <- FALSE # If TRUE, eliminate this gene from the model

    # Scan all the ORFS looking for a potential GC bias in a particular codon position.
    # This information will be used to acquire a good initial set of genes.

    gc_frame <- calc_most_gc_frame(sequence)

    # At this point, we expect all further modifications to the nodes to be made in a C/C++ environment,
    #   so we shift the node values that are node indices from a 1-based to a 0-based coordinate system.

    Nodes.df$ndx      <- Nodes.df$ndx      - 1
    Nodes.df$stop_val <- Nodes.df$stop_val - 1

    # Note: The Prodigal C function record_gc_bias has been split
    #   to update the NODE structure and the TRAINING structure separately
    # We do NOT update the TRAINING structure here

    Nodes.df <- as.data.frame(record_gc_bias_node(gc_frame, Nodes.df))

    # This will get an initial set of genes to train on.

    Nodes.df <- as.data.frame(record_overlapping_starts(Nodes.df, training, 0))

    # Find the genes for this sequence

    Genes.df <- as.data.frame(find_genes(Nodes.df, training, as.character(sequence), as.character(reverse)))

    # Rename the genes ...

    if (seqNum > 1) {
      for (i in 1:nrow(Genes.df)) {
        Genes.df$identifier[i] <- as.character(paste0(seqNum, "_", i + offset))
      }
    }

    offset <- offset + nrow(Genes.df)

    cat(paste0(" done!  ", nrow(Genes.df), " genes predicted\n"))

    allGenes.df <- rbind(allGenes.df, Genes.df, stringsAsFactors=FALSE)
  }

  return(allGenes.df)

}
