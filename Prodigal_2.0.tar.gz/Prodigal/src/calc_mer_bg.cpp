  #include <Rcpp.h> 
  using namespace Rcpp;

  // [[Rcpp::export]]
  DataFrame calc_mer_bg(const std::string& forward, const std::string& reverse) {

    #include <string>

    int mer_ndx (const std::string&);

    const int MER = 6; // Assumption: we are working with 6-mers

    int i;
    int n    = forward.size();
    int size = 1;
    int glob = 0;

    for (i = 0; i < MER; i++) size *= 4;

    IntegerVector counts(size);
    NumericVector bg(size);

    for (i = 0; i < size; i++) counts[i] = 0;

    for (i = 0; i < n-MER+1; i++) {
      counts[mer_ndx(forward.substr(i,MER))]++;
      counts[mer_ndx(reverse.substr(i,MER))]++;
      glob += 2;
    }

    for (i = 0; i < size; i++) {
      bg[i] = (double) counts[i] / (double) glob;
    }

    return DataFrame::create(
      Named("count") = counts,
      Named("bgrnd") = bg
    );
  }
