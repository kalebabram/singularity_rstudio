  #include <Rcpp.h> 
  using namespace Rcpp;

  // [[Rcpp::export]]
  int char2int (char a) {
    #include <string.h>

    if ( strncmp( &a, "A", 1) == 0 ) return(0);
    if ( strncmp( &a, "G", 1) == 0 ) return(1);
    if ( strncmp( &a, "C", 1) == 0 ) return(2);
    if ( strncmp( &a, "T", 1) == 0 ) return(3);
    return(-1);  // This should never be reached - may need to add check for N masking
  }
