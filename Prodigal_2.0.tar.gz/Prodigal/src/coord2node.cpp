  #include <Rcpp.h> 
  using namespace Rcpp;

  // [[Rcpp::export]]
  DataFrame coord2node(DataFrame CDF, int seq_len, int strand) {

    // Function used by the main prodigal function to create a node data frame
    //   from a sorted list of coordinate locations of STARTs and STOPs

    // Coordinate Data Frame
    IntegerVector   locate = CDF["locate"];
    CharacterVector pattrn = CDF["pattrn"];


    # include <string>
    # include <vector>
    # include <iostream>
  
    // Constant declarations and initializations
  
    const int MIN_GENE      = 87;   // Number of nucleotide bases, equivalent to 29 codons
    const int MIN_EDGE_GENE = 57;   // Check for potential genes at the edges of a contig
                                    // Note: This code classifies a gene that runs off the end of the contig
                                    //   as an EDGE gene, i.e., the node_edge value for such a gene is TRUE.
                                    //   This may differ from the C implementation.
      
    int nn          = 0,
        point       = 0,
        size        = 0,
        start       = 0,
        start_coord = 0,
        stop        = 0,
        stop_coord  = 0;

    int min_size;

    bool edge, stop_edge;

  
    // PASS 1 through the coordinate data to determine the number of nodes needed

    // Find the last STOP immediately after a START
    int last = pattrn.size() - 1;
    while (pattrn[last] != "STOP") { last -= 1; }
    while (pattrn[last] == "STOP") { last -= 1; }
    last++;
  
    while (point < last) {
      while (pattrn[point] == "STOP") { point++; } // Find the next START
      start = point; start_coord = locate[start];
      while (pattrn[point] != "STOP") { point++; } // Find the next STOP
      stop = point; stop_coord = locate[stop];
    
      size = stop_coord - start_coord;
      min_size = MIN_GENE;
      if ((start_coord < 4) || (stop_coord > seq_len-5)) { min_size = MIN_EDGE_GENE; }
      if (size >= min_size) {
        while (size >= min_size) {
          // A START node will be defined
          nn++;
          start_coord = locate[++start];
          size = stop_coord - start_coord;
          min_size = MIN_GENE;
          if ((start_coord < 4) || (stop_coord > seq_len-5)) { min_size = MIN_EDGE_GENE; }
        }
        // A STOP node will be defined
        nn++;
      }
    }
  
  
  
    // Rcpp data structures used to create the node data frame
    //   dimensioned with information from PASS 1
    CharacterVector node_type(nn);
    LogicalVector   node_edge(nn);  
    IntegerVector   node_index(nn);
    CharacterVector node_strand(nn);
    IntegerVector   node_stop_val(nn);
  



    // Reset the variables
    nn          = 0;
    point       = 0;
    size        = 0;
    start       = 0;
    start_coord = 0;
    stop        = 0;
    stop_coord  = 0;

    int curr_stop       = -1;
    int prev_stop       = -1;
    int prev_stop_coord =  0;


    // PASS 2 through the coordinate data to create the nodes dataframe  

    // Potential genes on either end of a sequence are permitted to be shorter,
    //   satisfying the MIN_EDGE_GENE length, rather than the MIN_GENE length.
    // However, a gene is classified as an EDGE gene ONLY IF it does NOT have a START.
    // Therefore, a gene that BEGINS off-sequence is an EDGE gene; a gene than ENDS off-sequence
    //   is NOT an EDGE gene.
    // A STOP node is an EDGE stop if it is created to stop a gene that would otherwise
    //   run off-sequence. Its purpose is to stop the gene at a point that insures an integral number of codons.

    // Forward strand
    curr_stop = -1;
    prev_stop = -1;

    if (strand == 1) {
      while (point < last) {
        while (pattrn[point] == "STOP") {   // Find the next START
          prev_stop = curr_stop;  prev_stop_coord = locate[prev_stop];
          curr_stop = point;
          point++;
        }
        start = point; start_coord = locate[start];
        while (pattrn[point] != "STOP") { point++; } // Find the next STOP
        stop = point; stop_coord = locate[stop];
        prev_stop = curr_stop;  prev_stop_coord = locate[prev_stop];
        curr_stop = point;
      
        size = stop_coord - start_coord;
        min_size = MIN_GENE; edge = FALSE; stop_edge = FALSE;
        if ((start_coord < 4) || (stop_coord > seq_len-5)) { min_size = MIN_EDGE_GENE; stop_edge = TRUE; }
        if  (start_coord < 4)                              { edge = TRUE; }
        if (size >= min_size) {
          while (size >= min_size) {
            // Add a START node
            node_type[nn]     = pattrn[start];
            node_edge[nn]     = edge;
            node_index[nn]    = start_coord;
            node_strand[nn]   = "+";
            node_stop_val[nn] = stop_coord;

if (0) {
if (start_coord == 1) {
  Rcout << "    " << pattrn[start] << std::endl;
  Rcout << "    " << edge << std::endl;
  Rcout << "    " << start_coord << std::endl;
  Rcout << "    +" << std::endl;
  Rcout << "    " << stop_coord << std::endl;
}
}
            nn++;
            start_coord = locate[++start];
            size = stop_coord - start_coord;
            min_size = MIN_GENE; edge = FALSE; stop_edge = FALSE;
            if ((start_coord < 4) || (stop_coord > seq_len-5)) { min_size = MIN_EDGE_GENE; stop_edge = TRUE; }
            if  (start_coord < 4)                              { edge = TRUE; }
          }
          // Add a STOP node

if (0) {
if (stop_coord == 1573) {
  Rcout << "    STOP" << std::endl;
  Rcout << "    " << stop_edge << std::endl;
  Rcout << "    " << stop_coord << std::endl;
  Rcout << "    +" << std::endl;
  Rcout << "    " << prev_stop_coord << std::endl;
}
}
          node_type[nn]     = "STOP";
          node_edge[nn]     = stop_edge;
          node_index[nn]    = stop_coord;
          node_strand[nn]   = "+";
          node_stop_val[nn] = prev_stop_coord;
          nn++;
        }
      }
    }
  
    // Reverse strand  
    curr_stop = -1;
    prev_stop = -1;
  
    if (strand == -1) {
      while (point < last) {
        while (pattrn[point] == "STOP") {   // Find the next START
          prev_stop = curr_stop;  prev_stop_coord = locate[prev_stop];
          curr_stop = point;
          point++;
        }
        start = point; start_coord = locate[start];
        while (pattrn[point] != "STOP") { point++; } // Find the next STOP
        stop = point; stop_coord = locate[stop];
        prev_stop = curr_stop;  prev_stop_coord = locate[prev_stop];
        curr_stop = point;
      
        size = stop_coord - start_coord;
        min_size = MIN_GENE; edge = FALSE; stop_edge = FALSE;
        if ((start_coord < 4) || (stop_coord > seq_len-5)) { min_size = MIN_EDGE_GENE; stop_edge = TRUE; }
        if  (start_coord < 4)                              { edge = TRUE; }
        if (size >= min_size) {
          while (size >= min_size) {
            // Add a START node
            node_type[nn]     = pattrn[start];
            node_edge[nn]     = edge;
            node_index[nn]    = seq_len - start_coord + 1;
            node_strand[nn]   = "-";
            node_stop_val[nn] = seq_len - stop_coord + 1;
            nn++;
            start_coord = locate[++start];
            size = stop_coord - start_coord;
            min_size = MIN_GENE; edge = FALSE; stop_edge = FALSE;
            if ((start_coord < 4) || (stop_coord > seq_len-5)) { min_size = MIN_EDGE_GENE; stop_edge = TRUE; }
            if  (start_coord < 4)                              { edge = TRUE; }
          }
          // Add a STOP node
          node_type[nn]     = "STOP";
          node_edge[nn]     = stop_edge;
          node_index[nn]    = seq_len - stop_coord + 1;
          node_strand[nn]   = "-";
          node_stop_val[nn] = seq_len - prev_stop_coord + 1;
          nn++;
        }
      }
    }
  
    return DataFrame::create(
      Named("type")     = node_type    ,
      Named("edge")     = node_edge    ,
      Named("ndx")      = node_index   ,
      Named("strand")   = node_strand  ,
      Named("stop_val") = node_stop_val
    );
  }
