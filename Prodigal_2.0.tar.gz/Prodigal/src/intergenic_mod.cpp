  #include <Rcpp.h> 
  using namespace Rcpp;


  // [[Rcpp::export]]
  double intergenic_mod(DataFrame NDF, List TL, int n1, int n2) {

    IntegerVector   node_ndx    = NDF["ndx"   ];
    CharacterVector node_strand = NDF["strand"];
    NumericVector   node_rscore = NDF["rscore"];
    NumericVector   node_uscore = NDF["uscore"];

    // double st_wt = as<double>(TL["st_wt"]); // st_wt is training "start weight"
    double st_wt = TL["st_wt"];

    const int OPER_DIST = 60;  // Something to do with operon distance

    int dist;
    double rval = 0.0,
           ovlp = 0.0;

    if ((node_strand[n1] == "+" && node_strand[n1] == "+" && (node_ndx[n1] + 2 == node_ndx[n2] || node_ndx[n1] - 1 == node_ndx[n2] )) ||
        (node_strand[n1] == "-" && node_strand[n1] == "-" && (node_ndx[n1] + 2 == node_ndx[n2] || node_ndx[n1] - 1 == node_ndx[n2] )))
    {
      if (node_strand[n1] == "+" && node_rscore[n2] < 0) rval -= node_rscore[n2];
      if (node_strand[n1] == "-" && node_rscore[n1] < 0) rval -= node_rscore[n1];
      if (node_strand[n1] == "+" && node_uscore[n2] < 0) rval -= node_uscore[n2];
      if (node_strand[n1] == "-" && node_uscore[n1] < 0) rval -= node_uscore[n1];
    }

    dist = abs(node_ndx[n1] - node_ndx[n2]);

    if      (node_strand[n1] == "+" && node_strand[n2] == "+" && node_ndx[n1]+2 >= node_ndx[n2]  ) ovlp = 1;
    else if (node_strand[n1] == "-" && node_strand[n2] == "-" && node_ndx[n1]   >= node_ndx[n2]+2) ovlp = 1;

    if (dist > 3*OPER_DIST || node_strand[n1] != node_strand[n2])
      rval -= 0.15 * st_wt;
    else if ((dist <= OPER_DIST && ovlp == 0) || dist < 0.25*OPER_DIST)
      rval += (2.0 - (double)(dist)/OPER_DIST) * 0.15 * st_wt;


    return (rval);
  }
