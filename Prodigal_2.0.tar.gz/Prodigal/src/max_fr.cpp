  #include <Rcpp.h> 
  using namespace Rcpp;

  // [[Rcpp::export]]
  int max_fr (int a, int b, int c) {  // Simple 3-way max function
    if (a > b)
      if (a > c) return 0; else return 2;
    else
      if (b > c) return 1; else return 2;
  }
