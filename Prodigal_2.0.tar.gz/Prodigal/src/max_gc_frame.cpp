  #include <Rcpp.h> 
  using namespace Rcpp;

  // [[Rcpp::export]]
  IntegerVector max_gc_frame(DataFrame DF) {

    IntegerVector gc1 = DF["gc1"];
    IntegerVector gc2 = DF["gc2"];
    IntegerVector gc3 = DF["gc3"];

    // The logic of this simple 3-way max function is identical to that of the Prodigal source code ...
    //   important because there are many potential ties in GC content between frames in a window.

    int n = gc1.length();

    // The decrement variable will be used to clean up the end of the gc_max_frame vector
    //   in case the frames are not all of the same length. Frames 2 or 3 may be one base shorter.
    //   The resulting gc_max_frame values match the corresponing Prodigal array values exactly.
    int dec = 0;
    if (gc2[n-1] == -1) { dec++; }
    if (gc3[n-1] == -1) { dec++; }

    IntegerVector gc_max_frame(n*3-dec);

    int last = n;
    if (dec) { last--; }

    int gg = 0;
    for (int i = 0; i < last; i++) {
      if ( gc1[i] > gc2[i] ) {
        if ( gc1[i] > gc3[i] ) { gc_max_frame[gg++] = 0; gc_max_frame[gg++] = 0; gc_max_frame[gg++] = 0; }
        else                   { gc_max_frame[gg++] = 2; gc_max_frame[gg++] = 2; gc_max_frame[gg++] = 2; }
      }
      else {
        if ( gc2[i] > gc3[i] ) { gc_max_frame[gg++] = 1; gc_max_frame[gg++] = 1; gc_max_frame[gg++] = 1; }
        else                   { gc_max_frame[gg++] = 2; gc_max_frame[gg++] = 2; gc_max_frame[gg++] = 2; }
      }
    }

    // Write -1 for any remaining bases in an incomplete frame
    //   e.g., if two bases short (dec=2) write once, since frame contains only one base
    if (dec) {
     for (int i = 0; i < (3-dec); i++) {
       gc_max_frame[gg++] = -1;
     }
    }

    return (gc_max_frame);
  }
