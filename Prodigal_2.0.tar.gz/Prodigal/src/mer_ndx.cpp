#include <Rcpp.h> 
using namespace Rcpp;

// [[Rcpp::export]]
int mer_ndx (const std::string& motif) {
  #include <string>
  using namespace std;

  int char2int (char);

  int len = motif.size();

  int mul = 1,
      sum = 0;

  for ( int i = 0; i < len; i++ ) {
    int c = char2int(motif[i]);
    sum += (c * mul);
    mul *= 4;
  }
  return(sum);
}
