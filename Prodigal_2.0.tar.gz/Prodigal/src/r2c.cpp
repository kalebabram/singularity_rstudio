#include <Rcpp.h>
using namespace Rcpp;

#include <iostream>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <vector>
// #include <array>
#include <string>

class _motif {
  public:
    int ndx;             /* Index of the best motif for this node */
    int len;             /* Length of the motif */
    int spacer;          /* Spacer between coding start and the motif */
    int spacendx;        /* Index for this spacer length */
    double score;        /* Score for the motif */
};


class _node {
  public:
    int type;            /* 0=ATG, 1=GTG, 2=TTG/Other, 3=Stop */
    int edge;            /* Runs off the edge; 0 = normal, 1 = edge node */
    int ndx;             /* position in the sequence of the node */
    int strand;          /* 1 = forward, -1 = reverse */
    int stop_val;        /* For a stop, record previous stop; for start, record its stop */
    int star_ptr[3];     /* Array of starts w/in MAX_SAM_OVLP bases of a stop in 3 frames */
    int gc_bias;         /* Frame of highest GC content within this node */
    double gc_score[3];  /* % GC content in different codon positions */
    double cscore;       /* Coding score for this node -- based on 6-mer usage */
    double gc_cont;      /* GC Content for the node */
    int rbs[2];          /* SD RBS score for this node -- based on binding energy
                            rbs[0] = best motif with exact match, rbs[1] = with mismatches */
    class _motif mot;    /* Upstream motif information for this node */
    double uscore;       /* Score for the upstream -1/-2, -15 to -45 region */
    double tscore;       /* Score for the ATG/GTG/TTG value */
    double rscore;       /* Score for the RBS motif */
    double sscore;       /* Score for the strength of the start codon */
    int traceb;          /* Traceback to connecting node */
    int tracef;          /* Forward trace */
    int ov_mark;         /* Marker to help untangle overlapping genes */
    double score;        /* Score of total solution to this point */
    int elim;            /* If set to 1, eliminate this gene from the model */
};


class _training {
  public:
    double gc;                    /* GC Content */
    int trans_table;              /* 11 = Standard Microbial, NCBI Trans Table to use */
    double st_wt;                 /* Start weight */
    double bias[3];               /* GC frame bias for each of the 3 positions */
    double type_wt[3];            /* Weights for ATG vs GTG vs TTG */
    int uses_sd;                  /* 0 if does not use SD motif, 1 if it does */
    double rbs_wt[28];            /* Set of weights for RBS scores */
    double ups_comp[32][4];       /* Base composition weights for non-RBS-distance motifs:
                                     0-1 are the -1/-2 position,
                                     2-31 are the -15 to -44 positions.
                                     Second array is the base A,C,T,G,etc. */
    double mot_wt[4][4][4096];    /* Weights for upstream motifs:
                                     First index is the motif length -- 3-6.
                                     Second index is the spacer distance -- 0 = 5-10bp, 1 = 3-4bp, 2 = 11-12bp, 3 = 13-15bp.
                                     Third index is the numerical value of the motif
                                       ranging from 0 to 4095 for 6-mers, less for shorter motifs */
    double no_mot;                /* Weight for the case of no motif */
    double gene_dc[4096];         /* Coding statistics for the genome */
};


class _gene {
  public:
    char identifier[10];     /* Gene identifier */
    int begin;               /* Left end of the gene */
    int end;                 /* Right end of the gene */
    int strand;              /* Strand */
    int start_ndx;           /* Index to the start node in the nodes file */
    int stop_ndx;            /* Index to the stop node in the nodes file */
    char partial[3];         /* 1 = partial, 0 = not partial, 1st position = left, 2nd position = right */
    char start_type[5];      /* 0 = "ATG", 1 = "GTG", 2 = "TTG" , 3 = "Edge" */
    char rbs_motif[15];      /* RBS motif */
    char rbs_spacer[8];      /* RBS spacer */
    double gc_cont;          /* GC content of the gene */
    double confidence;       /* Percentage confidence of the gene call */
    double score;            /* Sum of the cscore and the score */
    double cscore;           /* Coding score for this gene -- based on 6-mer usage */
    double sscore;           /* Score for the strength of the start codon */
    double rscore;           /* Score for the RBS motif */
    double uscore;           /* Score for the upstream -1/-2, -15 to -45 region */
    double tscore;           /* Score for the ATG/GTG/TTG value */
    char *sequence;
    char *protein;

};





#define ATG  0
#define GTG  1
#define TTG  2
#define STOP 3

#define MAX_NODE_DIST 500
#define MAX_SAM_OVLP   60  // Number of nucleotide bases permitted in an overlap on the same strand
#define MAX_OPP_OVLP  200  // Number of nucleotide bases permitted in an overlap on the opposite strand
#define OPER_DIST      60  // Something to do with operon distance
#define EDGE_BONUS   0.74
#define EDGE_UPS    -1.00
#define META_PEN      7.5




int im_calls = 0,
    sc_calls = 0,
    mn_calls = 0;


    

double intergenic_mod(class _node *n1, class _node *n2, class _training *tinf) {

  int dist;

  double rval = 0.0,
         ovlp = 0.0;

  im_calls++;



  if ((n1->strand ==  1 && n2->strand ==  1 && (n1->ndx + 2 == n2->ndx || n1->ndx - 1 == n2->ndx)) ||
      (n1->strand == -1 && n2->strand == -1 && (n1->ndx + 2 == n2->ndx || n1->ndx - 1 == n2->ndx)))
  {
    if (n1->strand ==  1 && n2->rscore < 0) rval -= n2->rscore;
    if (n1->strand == -1 && n1->rscore < 0) rval -= n1->rscore;
    if (n1->strand ==  1 && n2->uscore < 0) rval -= n2->uscore;
    if (n1->strand == -1 && n1->uscore < 0) rval -= n1->uscore;
  }

  dist = abs(n1->ndx-n2->ndx);

  if      (n1->strand ==  1 && n2->strand ==  1 && n1->ndx+2 >= n2->ndx  ) ovlp = 1;
  else if (n1->strand == -1 && n2->strand == -1 && n1->ndx   >= n2->ndx+2) ovlp = 1;
  if (dist > 3*OPER_DIST || n1->strand != n2->strand) {
    rval -= 0.15 * tinf->st_wt;
  }
  else if ((dist <= OPER_DIST && ovlp == 0) || dist < 0.25*OPER_DIST) {
    rval += (2.0 - (double)(dist)/OPER_DIST) * 0.15 * tinf->st_wt;
  }

  return rval;
}





void score_connection(class _node *nod, int p1, int p2, class _training *tinf, int flag) {

  // These definitions are repeated from the main dprog function

  class _node *n1 = &(nod[p1]),
              *n2 = &(nod[p2]),
              *n3;
  int i,
      left  = n1->ndx,
      right = n2->ndx,
      bnd,
      ovlp = 0,
      maxfr = -1;

  double score   = 0.0,
         scr_mod = 0.0,
         maxval;


  sc_calls++;




  // *******************
  // Invalid Connections
  // *******************

  // 5-prime forward -> 5-prime forward, 5-prime reverse -> 5-prime reverse
  if (n1->type != STOP && n2->type != STOP && n1->strand == n2->strand) return;

  // 5-prime forward -> 5-prime reverse, 5-prime forward -> 3-prime reverse
  else if (n1->strand == 1 && n1->type != STOP && n2->strand == -1) return;

  // 3-prime reverse -> 5-prime forward, 3-prime reverse -> 3-prime forward
  else if (n1->strand == -1 && n1->type == STOP && n2->strand == 1) return;

  // 5-prime reverse -> 3-prime forward
  else if (n1->strand == -1 && n1->type != STOP && n2->strand == 1 && n2->type == STOP) return;

  // **************
  // Edge Artifacts
  // **************

  if (n1->traceb == -1 && n1->strand ==  1 && n1->type == STOP) return;
  if (n1->traceb == -1 && n1->strand == -1 && n1->type != STOP) return;

  // *****
  // Genes
  // *****

  // 5-prime forward -> 3-prime forward
  else if (n1->strand == n2->strand && n1->strand == 1 && n1->type != STOP && n2->type == STOP) {
    if (n2->stop_val >= n1->ndx) return;
    if (n1->ndx % 3 != n2->ndx % 3) return;
    right += 2;
    if      (flag == 0) scr_mod = tinf->bias[0]*n1->gc_score[0] + tinf->bias[1]*n1->gc_score[1] + tinf->bias[2]*n1->gc_score[2];
    else if (flag == 1) score = n1->cscore + n1->sscore;
  }

  // 3-prime reverse -> 5-prime reverse
  else if (n1->strand == n2->strand && n1->strand == -1 && n1->type == STOP && n2->type != STOP) {
    if (n1->stop_val <= n2->ndx) return;
    if (n1->ndx % 3 != n2->ndx % 3) return;
    left -= 2;
    if      (flag == 0) scr_mod = tinf->bias[0]*n2->gc_score[0] + tinf->bias[1]*n2->gc_score[1] + tinf->bias[2]*n2->gc_score[2];
    else if (flag == 1) score = n2->cscore + n2->sscore;
  }

  // ****************************
  // Intergenic Space (Noncoding)
  // ****************************

  // 3-prime forward -> 5-prime forward
  else if (n1->strand == 1 && n1->type == STOP && n2->strand == 1 && n2->type != STOP) {
    left += 2;
    if (left >= right) return;
    if (flag == 1) score = intergenic_mod(n1, n2, tinf);
  } 

  // 3-prime forward -> 3-prime reverse
  else if (n1->strand == 1 && n1->type == STOP && n2->strand == -1 && n2->type == STOP) {
    left  += 2;
    right -= 2;
    if (left >= right) return;

    // Overlapping Gene Case 2: Three consecutive overlapping genes f r r
    maxfr  =  -1;
    maxval = 0.0;
    for (i = 0; i < 3; i++) {
      if (n2->star_ptr[i] == -1) continue;
      n3 = &(nod[n2->star_ptr[i]]);
      ovlp = left - n3->stop_val + 3;
      if (ovlp <= 0 || ovlp >= MAX_OPP_OVLP) continue;
      if (ovlp >= n3->ndx - left) continue;
      if (n1->traceb == -1) continue;
      if (ovlp >= n3->stop_val - nod[n1->traceb].ndx - 2) continue;
      if ((flag == 1 && n3->cscore + n3->sscore + intergenic_mod(n3, n2, tinf) > maxval) ||
          (flag == 0 && tinf->bias[0]*n3->gc_score[0] + tinf->bias[1]*n3->gc_score[1] + tinf->bias[2]*n3->gc_score[2] > maxval))
      {
        maxfr  = i;
        maxval = n3->cscore + n3->sscore + intergenic_mod(n3, n2, tinf);
      }
    }
    if (maxfr != -1) {
      n3 = &(nod[n2->star_ptr[maxfr]]);
      if      (flag == 0) scr_mod = tinf->bias[0]*n3->gc_score[0] + tinf->bias[1]*n3->gc_score[1] + tinf->bias[2]*n3->gc_score[2];
      else if (flag == 1) score = n3->cscore + n3->sscore + intergenic_mod(n3, n2, tinf);
    }
    else if (flag == 1) score = intergenic_mod(n1, n2, tinf);
  }

  // 5-prime reverse -> 3-prime reverse
  else if (n1->strand == -1 && n1->type != STOP && n2->strand == -1 && n2->type == STOP) {
    right -= 2;
    if (left >= right) return;
    if (flag == 1) score = intergenic_mod(n1, n2, tinf);
  }

  // 5-prime reverse -> 5-prime forward
  else if (n1->strand == -1 && n1->type != STOP && n2->strand ==  1 && n2->type != STOP) {
    if (left >= right) return;
    if (flag == 1) score = intergenic_mod(n1, n2, tinf);
  }

  // ****************
  // Possible Operons
  // ****************

  // 3-prime forward -> 3-prime forward, check for a start just to left of first 3-prime
  else if (n1->strand == 1 && n2->strand == 1 && n1->type == STOP && n2->type == STOP) {
    if (n2->stop_val >= n1->ndx) return;
    if (n1->star_ptr[n2->ndx%3] == -1) return;
    n3 = &(nod[n1->star_ptr[n2->ndx%3]]);
    left = n3->ndx; right += 2;
    if      (flag == 0) scr_mod = tinf->bias[0]*n3->gc_score[0] + tinf->bias[1]*n3->gc_score[1] + tinf->bias[2]*n3->gc_score[2];
    else if (flag == 1) score = n3->cscore + n3->sscore + intergenic_mod(n1, n3, tinf);
  }

  // 3-prime reverse -> 3-prime reverse, check for a start just to right of second 3-prime
  else if (n1->strand == -1 && n1->type == STOP && n2->strand == -1 && n2->type == STOP) {
    if (n1->stop_val <= n2->ndx) return;
    if (n2->star_ptr[n1->ndx%3] == -1) return;
    n3 = &(nod[n2->star_ptr[n1->ndx%3]]);
    left -= 2; right = n3->ndx;
    if      (flag == 0) scr_mod = tinf->bias[0]*n3->gc_score[0] + tinf->bias[1]*n3->gc_score[1] + tinf->bias[2]*n3->gc_score[2];
    else if (flag == 1) score = n3->cscore + n3->sscore + intergenic_mod(n3, n2, tinf);
  }

  // ****************************************
  // Overlapping Opposite Strand 3-prime Ends
  // ****************************************

  // 3-prime forward ->5-prime reverse
  else if (n1->strand == 1 && n1->type == STOP && n2->strand == -1 && n2->type != STOP) {
    if (n2->stop_val-2 >= n1->ndx+2) return;
    ovlp = (n1->ndx+2) - (n2->stop_val-2) + 1;
    if (ovlp >= MAX_OPP_OVLP) return;
    if ((n1->ndx+2 - n2->stop_val-2 + 1) >= (n2->ndx -n1->ndx+3 + 1)) return;
    if (n1->traceb == -1) bnd = 0;
    else                  bnd = nod[n1->traceb].ndx;
    if ((n1->ndx+2 - n2->stop_val-2 + 1) >= (n2->stop_val-3 - bnd + 1)) return;
    left = n2->stop_val-2;
    if      (flag == 0) scr_mod = tinf->bias[0]*n2->gc_score[0] + tinf->bias[1]*n2->gc_score[1] + tinf->bias[2]*n2->gc_score[2];
    else if (flag == 1) score = n2->cscore + n2->sscore - 0.15*tinf->st_wt;
  }

  if (flag == 0) score = ((double)(right-left+1-(ovlp*2)))*scr_mod;

  if (n1->score + score >= n2->score) {
    n2->score = n1->score + score;
    n2->traceb = p1;
    n2->ov_mark = maxfr;
  }

  return;
}






int dprog(class _node *nod, int nn, class _training *tinf, int flag) {

  int i,
      j,
      min,
      max_ndx = -1,
      path,
      nxt,
      tmp;

  double max_sc = -1.0;

  if (nn == 0) return -1;   // This condition should never be true

  for (i = 0; i < nn; i++) {
    nod[i].score  =  0;
    nod[i].traceb = -1;
    nod[i].tracef = -1;
  }

  for(i = 0; i < nn; i++) {

    // Set up distance constraints for making connections, but make exceptions for giant ORFS.

    if (i < MAX_NODE_DIST) min = 0;
    else                   min = i - MAX_NODE_DIST;

    if (nod[i].strand == -1 && nod[i].type != STOP && nod[min].ndx >= nod[i].stop_val)
      while (min >= 0 && nod[i].ndx != nod[i].stop_val) min--;
    if (nod[i].strand ==  1 && nod[i].type == STOP && nod[min].ndx >= nod[i].stop_val)
      while (min >= 0 && nod[i].ndx != nod[i].stop_val) min--;
    if (min < MAX_NODE_DIST) min = 0;
    else                     min = min - MAX_NODE_DIST;
    for (j = min; j < i; j++) {
      score_connection(nod, j, i, tinf, flag);
    }
  }

  for (i = nn-1; i >= 0; i--) {
    if (nod[i].strand ==  1 && nod[i].type != STOP) continue;
    if (nod[i].strand == -1 && nod[i].type == STOP) continue;
    if (nod[i].score > max_sc) {
      max_sc = nod[i].score;
      max_ndx = i;
    }
  }


  // First Pass: untangle the triple overlaps

  path = max_ndx;
  while (nod[path].traceb != -1) {
    nxt = nod[path].traceb;
    if (nod[path].strand == -1 && nod[path].type == STOP &&
        nod[nxt].strand  ==  1 && nod[nxt].type  == STOP &&
        nod[path].ov_mark != -1 && nod[path].ndx > nod[nxt].ndx)
    {
      tmp = nod[path].star_ptr[nod[path].ov_mark];
      for (i = tmp; nod[i].ndx != nod[tmp].stop_val; i--);
      nod[path].traceb = tmp;
      nod[tmp].traceb = i;
      nod[i].ov_mark = -1;
      nod[i].traceb = nxt;
    }
    path = nod[path].traceb;
  }


  // Second Pass: Untangle the simple overlaps

  path = max_ndx;
  while (nod[path].traceb != -1) {
    nxt = nod[path].traceb;
    if (nod[path].strand == -1 && nod[path].type != STOP &&
        nod[nxt].strand  ==  1 && nod[nxt].type  == STOP)
    {
      for (i = path; nod[i].ndx != nod[path].stop_val; i--);
      nod[path].traceb = i;
      nod[i].traceb = nxt;
    }
    if (nod[path].strand == 1 && nod[path].type == STOP &&
        nod[nxt].strand  == 1 && nod[nxt].type  == STOP)
    {
      nod[path].traceb = nod[nxt].star_ptr[(nod[path].ndx)%3];
      nod[nod[path].traceb].traceb = nxt;
    }
    if (nod[path].strand == -1 && nod[path].type == STOP &&
        nod[nxt].strand ==  -1 && nod[nxt].type  == STOP)
    {
      nod[path].traceb = nod[path].star_ptr[(nod[nxt].ndx)%3];
      nod[nod[path].traceb].traceb = nxt;
    }
    path = nod[path].traceb;
  }


  // Mark forward pointers

  path = max_ndx;
  while (nod[path].traceb != -1) {
    nod[nod[path].traceb].tracef = path;
    path = nod[path].traceb;
  }

  if (nod[max_ndx].traceb == -1) return -1;
  else                           return max_ndx;

}



int char2int_C (char a) {

  // Note: There are two versions of char2int ... one in R, this one in C.
  // It is given the _C suffix to eliminate duplicate symbol error during package build.

  if ( strncmp( &a, "A", 1) == 0 ) return(0);
  if ( strncmp( &a, "G", 1) == 0 ) return(1);
  if ( strncmp( &a, "C", 1) == 0 ) return(2);
  if ( strncmp( &a, "T", 1) == 0 ) return(3);
  return(-1);  // This should never be reached - may need to add check for N masking
}








int mer_ndx (int len, char *seq, int pos) {

  int c,
      i,
      mul = 1,
      sum = 0;

  mn_calls++;

  for (i = 0; i < len; i++) {
    c = char2int_C(seq[pos+i]);
    sum += (c * mul);
    mul *= 4;
  }

  return (sum);
}









void calc_mer_bg(int len, char *seq, char *rseq, int slen, double *bg) {

  int i,
      glob = 0,
      size = 1;

  //  int *counts;

  for (i = 1; i <= len; i++)
    size *= 4;

  int counts[size];

  //  counts = (int *)malloc(size * sizeof(int));

  for (i = 0; i < size; i++)
    counts[i] = 0;

  for (i = 0; i < slen-len+1; i++) {
    counts[mer_ndx(len, seq , i)]++;
    counts[mer_ndx(len, rseq, i)]++;
    glob += 2;
  }

  for (i = 0; i < size; i++)
    bg[i] = (double)((counts[i]*1.0)/(glob*1.0));

  // Debug statement
  if (0) {
    Rcout << "In background count:   glob: " << glob << std::endl;
    Rcout << 2154 << " " << counts[2154] << std::endl;
    Rcout << 1691 << " " << counts[1691] << std::endl;
    Rcout << 1759 << " " << counts[1759] << std::endl;
    Rcout << 1754 << " " << counts[1754] << std::endl;
    Rcout << 1691 << " " << counts[1691] << std::endl;
    Rcout << 1784 << " " << counts[1784] << std::endl;
    Rcout << 3557 << " " << counts[3557] << std::endl;
  }

}










void calc_dicodon_gene(class _training *tinf, char *seq, char *rseq, int slen, class _node *nod, int dbeg) {

  int counts[4096],
      glob = 0,
      i, j,
      in_gene,
      left,
      path,
      right;


  double prob[4096],
         bg[4096];

  for  (i = 0; i < 4096; i++) {
    counts[i] = 0;
    prob[i]   = 0.0;
    bg[i]     = 0.0;
  }

  left = -1;
  right = -1;

  calc_mer_bg(6, seq, rseq, slen, bg);



  path = dbeg;
  in_gene = 0;

  while (path != -1) {

    if (nod[path].strand == -1 && nod[path].type != STOP) {
      in_gene = -1;
      left    = slen-nod[path].ndx-1;
    }

    if (nod[path].strand ==  1 && nod[path].type == STOP) {
      in_gene = 1;
      right   = nod[path].ndx+2;
    }

    if (in_gene == -1 && nod[path].strand == -1 && nod[path].type == STOP) {
      right = slen-nod[path].ndx+1;
      for (i = left; i < right-5; i+=3) {
        // counts[mer_ndx(6, rseq, i)]++;
        j = mer_ndx(6, rseq, i);
        counts[j]++;
        glob++;
      }
      in_gene = 0;
    }

    if(in_gene == 1 && nod[path].strand == 1 && nod[path].type != STOP) {
      left = nod[path].ndx;
      for (i = left; i < right-5; i+=3) {
        // counts[mer_ndx(6, seq, i)]++;
        j = mer_ndx(6, seq, i);
        counts[j]++;
        glob++;
      }
      in_gene = 0;
    }
    path = nod[path].traceb;
  }

  for(i = 0; i < 4096; i++) {

    prob[i] = (counts[i]*1.0)/(glob*1.0);
    if (prob[i] == 0 && bg[i] != 0) tinf->gene_dc[i] = -5.0;
    else if (bg[i] == 0) tinf->gene_dc[i] = 0.0;
    else tinf->gene_dc[i] = log(prob[i]/bg[i]);

    if (tinf->gene_dc[i] >  5.0) tinf->gene_dc[i] =  5.0;
    if (tinf->gene_dc[i] < -5.0) tinf->gene_dc[i] = -5.0;

  }
  

  // Debug statement
  if (0) {
    Rcout << "In genes count:   glob: " << glob << std::endl;
    Rcout << 2154 << " " << counts[2154] << std::endl;
    Rcout << 1691 << " " << counts[1691] << std::endl;
    Rcout << 1759 << " " << counts[1759] << std::endl;
    Rcout << 1754 << " " << counts[1754] << std::endl;
    Rcout << 1691 << " " << counts[1691] << std::endl;
    Rcout << 1784 << " " << counts[1784] << std::endl;
    Rcout << 3557 << " " << counts[3557] << std::endl;
  }


}







int imin(int x, int y) {
// Returns the minimum of two numbers
  if (x < y) return x;
  return y;
}








int shine_dalgarno_exact(char *seq, int pos, int start, double *rwt) {
// Finds the highest-scoring region similar to AGGAGG in a given stretch of sequence upstream of a start.

  int i,
      j,
      k,
      mism,
      rdis,
      limit,
      max_val,
      cur_val = 0;

  double match[6],
         cur_ctr,
         dis_flag;

  limit = imin(6, start-4-pos);

  for (i = limit; i < 6; i++)
    match[i] = -10.0;

  // Compare the 6-base region to AGGAGG
  for (i = 0; i < limit; i++) {
    if (pos+i < 0) continue;
    // if      (i%3 == 0 && is_a(seq, pos+i) == 1) match[i] = 2.0;
    // else if (i%3 != 0 && is_g(seq, pos+i) == 1) match[i] = 3.0;
    if      (i%3 == 0 && strncmp(&seq[pos+i], "A", 1) == 0) match[i] = 2.0;
    else if (i%3 != 0 && strncmp(&seq[pos+i], "G", 1) == 0) match[i] = 3.0;
    else match[i] = -10.0;
  }



  // Find the maximally scoring motif 
  max_val = 0;
  for (i = limit; i >= 3; i--) {
    for (j = 0; j <= limit-i; j++) {
      cur_ctr = -2.0;
      mism = 0;
      for (k = j; k < j+i; k++) {
        cur_ctr += match[k];
        if (match[k] < 0.0) mism++;
      }
      if(mism > 0) continue;
      rdis = start - (pos+j+i);
      if      (rdis < 5                && i <  5) dis_flag = 2;
      else if (rdis < 5                && i >= 5) dis_flag = 1;
      else if (rdis > 10 && rdis <= 12 && i <  5) dis_flag = 1;
      else if (rdis > 10 && rdis <= 12 && i >= 5) dis_flag = 2;
      else if (rdis >= 13) { dis_flag = 3; }
      else dis_flag = 0;
      if (rdis > 15 || cur_ctr < 6.0) continue;

      // Exact-Matching RBS Motifs
      if      (cur_ctr <   6.0) cur_val = 0;
      else if (cur_ctr ==  6.0 && dis_flag == 2) cur_val =  1;
      else if (cur_ctr ==  6.0 && dis_flag == 3) cur_val =  2;
      else if (cur_ctr ==  8.0 && dis_flag == 3) cur_val =  3;
      else if (cur_ctr ==  9.0 && dis_flag == 3) cur_val =  3;
      else if (cur_ctr ==  6.0 && dis_flag == 1) cur_val =  6;
      else if (cur_ctr == 11.0 && dis_flag == 3) cur_val = 10;
      else if (cur_ctr == 12.0 && dis_flag == 3) cur_val = 10;
      else if (cur_ctr == 14.0 && dis_flag == 3) cur_val = 10;
      else if (cur_ctr ==  8.0 && dis_flag == 2) cur_val = 11;
      else if (cur_ctr ==  9.0 && dis_flag == 2) cur_val = 11;
      else if (cur_ctr ==  8.0 && dis_flag == 1) cur_val = 12;
      else if (cur_ctr ==  9.0 && dis_flag == 1) cur_val = 12;
      else if (cur_ctr ==  6.0 && dis_flag == 0) cur_val = 13;
      else if (cur_ctr ==  8.0 && dis_flag == 0) cur_val = 15;
      else if (cur_ctr ==  9.0 && dis_flag == 0) cur_val = 16;
      else if (cur_ctr == 11.0 && dis_flag == 2) cur_val = 20;
      else if (cur_ctr == 11.0 && dis_flag == 1) cur_val = 21;
      else if (cur_ctr == 11.0 && dis_flag == 0) cur_val = 22;
      else if (cur_ctr == 12.0 && dis_flag == 2) cur_val = 20;
      else if (cur_ctr == 12.0 && dis_flag == 1) cur_val = 23;
      else if (cur_ctr == 12.0 && dis_flag == 0) cur_val = 24;
      else if (cur_ctr == 14.0 && dis_flag == 2) cur_val = 25;
      else if (cur_ctr == 14.0 && dis_flag == 1) cur_val = 26;
      else if (cur_ctr == 14.0 && dis_flag == 0) cur_val = 27;

      if (rwt[cur_val] < rwt[max_val]) continue;
      if (rwt[cur_val] == rwt[max_val] && cur_val < max_val) continue;
      max_val = cur_val;
    }
  }

  return max_val;
}





int shine_dalgarno_mm(char *seq, int pos, int start, double *rwt) {
// Finds the highest-scoring region similar to AGGAGG in a given stretch of sequence upstream of a start.
// Only considers 5/6-mers with 1 mismatch.

  int i,
  j,
  k,
  mism,
  rdis,
  limit,
  max_val,
  cur_val = 0;

  double match[6],
         cur_ctr,
         dis_flag;

  limit = imin(6, start-4-pos);

  for (i = limit; i < 6; i++)
    match[i] = -10.0;

  // Compare the 6-base region to AGGAGG
  for(i = 0; i < limit; i++) {
    if (pos+i < 0) continue;
    if (i % 3 == 0) {
      if (strncmp(&seq[pos+i], "A", 1) == 0) match[i] = 2.0;
      else match[i] = -3.0;
    }
    else {
      if (strncmp(&seq[pos+i], "G", 1) == 0) match[i] = 3.0;
      else match[i] = -2.0;
    }
  }

  // Find the maximally scoring motif
  max_val = 0;
  for (i = limit; i >= 5; i--) {
    for (j = 0; j <= limit-i; j++) {
      cur_ctr = -2.0;
      mism = 0;
      for (k = j; k < j+i; k++) {
        cur_ctr += match[k];
        if (match[k] < 0.0) mism++;
        if (match[k] < 0.0 && (k <= j+1 || k >= j+i-2))
          cur_ctr -= 10.0;
      }
      if (mism != 1) continue;
      rdis = start - (pos+j+i);
      if      (rdis < 5)                { dis_flag = 1; }
      else if (rdis > 10 && rdis <= 12) { dis_flag = 2; }
      else if (rdis >= 13)                { dis_flag = 3; }
      else dis_flag = 0;
      if (rdis > 15 || cur_ctr < 6.0) continue;

      // Single-Mismatch RBS Motifs
      if      (cur_ctr <  6.0)                  cur_val =  0;
      else if (cur_ctr == 6.0 && dis_flag == 3) cur_val =  2;
      else if (cur_ctr == 7.0 && dis_flag == 3) cur_val =  2;
      else if (cur_ctr == 9.0 && dis_flag == 3) cur_val =  3;
      else if (cur_ctr == 6.0 && dis_flag == 2) cur_val =  4;
      else if (cur_ctr == 6.0 && dis_flag == 1) cur_val =  5;
      else if (cur_ctr == 6.0 && dis_flag == 0) cur_val =  9;
      else if (cur_ctr == 7.0 && dis_flag == 2) cur_val =  7;
      else if (cur_ctr == 7.0 && dis_flag == 1) cur_val =  8;
      else if (cur_ctr == 7.0 && dis_flag == 0) cur_val = 14;
      else if (cur_ctr == 9.0 && dis_flag == 2) cur_val = 17;
      else if (cur_ctr == 9.0 && dis_flag == 1) cur_val = 18;
      else if (cur_ctr == 9.0 && dis_flag == 0) cur_val = 19;

      if (rwt[cur_val] <  rwt[max_val]) continue;
      if (rwt[cur_val] == rwt[max_val] && cur_val < max_val) continue;
      max_val = cur_val;
    }
  }

  return max_val;
}








void rbs_score(char *seq, char *rseq, int slen, class _node *nod, int nn, class _training *tinf) {

  int i, j;
  int cur_sc[2];

  // Scan all starts looking for RBSs

  for (i = 0; i < nn; i++) {
    if (nod[i].type == STOP || nod[i].edge == 1) continue;
    nod[i].rbs[0] = 0;
    nod[i].rbs[1] = 0;
    if (nod[i].strand == 1) {
      for (j = nod[i].ndx - 20; j <= nod[i].ndx - 6; j++) {
        if (j < 0) continue;
        cur_sc[0] = shine_dalgarno_exact(seq, j, nod[i].ndx, tinf->rbs_wt);
        cur_sc[1] = shine_dalgarno_mm(seq, j, nod[i].ndx, tinf->rbs_wt);
        if (cur_sc[0] > nod[i].rbs[0]) nod[i].rbs[0] = cur_sc[0];
        if (cur_sc[1] > nod[i].rbs[1]) nod[i].rbs[1] = cur_sc[1];
      }
    }

    else if (nod[i].strand == -1) {
      for (j = slen - nod[i].ndx - 21; j <= slen - nod[i].ndx - 7; j++) {
        if (j > slen-1) continue;
        cur_sc[0] = shine_dalgarno_exact(rseq, j, slen-1-nod[i].ndx, tinf->rbs_wt);
        cur_sc[1] = shine_dalgarno_mm(rseq, j, slen-1-nod[i].ndx, tinf->rbs_wt);
        if (cur_sc[0] > nod[i].rbs[0]) nod[i].rbs[0] = cur_sc[0];
        if (cur_sc[1] > nod[i].rbs[1]) nod[i].rbs[1] = cur_sc[1];
      }
    }
  }
}





void count_upstream_composition(char *seq, int slen, int strand, int pos, class _training *tinf) {

  // For a given start, record the base composition of the upstream region at positions -1 and -2 and -15 to -44.
  // This will be used to supplement the SD (or other) motif finder with additional information.

  int i,
      start,
      count = 0;

  if (strand == 1) start = pos;
  else             start = slen-1 - pos;

  for (i = 1; i < 45; i++) {
    if (i > 2 && i < 15) continue;
    if (start-i >= 0)
      tinf->ups_comp[count][mer_ndx(1, seq, start-i)]++;
    count++;
  }
}








double dmax(double x, double y) {

// Return the maximum of two numbers
  if (x > y) return x;
  return y;
}

double dmin(double x, double y) {

// Return the minimum of two numbers
  if (x < y) return x;
  return y;
}








void train_starts_sd(char *seq, char *rseq, int slen, class _node *nod, int nn, class _training *tinf) {

  int i,
      j,
      fr,
      rbs[3],
      type[3],
      bndx[3],
      max_rb;

  double sum,
         wt,
         rbg[28],
         rreal[28],
         best[3],
         sthresh = 35.0;
  double tbg[3],
         treal[3];

  wt = tinf->st_wt;

  for (j = 0; j <  3; j++) tinf->type_wt[j] = 0.0;
  for (j = 0; j < 28; j++) tinf->rbs_wt[j]  = 0.0;

  for (i = 0; i < 32; i++)
    for (j = 0; j < 4; j++)
      tinf->ups_comp[i][j] = 0.0;

  // Build the background of random types
  for (i = 0; i < 3; i++) tbg[i] = 0.0;
  for (i = 0; i < nn; i++) {
    if (nod[i].type == STOP) continue;
    tbg[nod[i].type] += 1.0;
  }
  sum = 0.0;
  for (i = 0; i < 3; i++) sum += tbg[i];
  for (i = 0; i < 3; i++) tbg[i] /= sum;


  // Debug statement
  if (0) {
    Rcout << "tbg " << tbg[0] << " " << tbg[1] << " " << tbg[2] << std::endl;
  }

  // Iterate 10 times through the list of nodes
  // Converge upon optimal weights for ATG vs GTG vs TTG and RBS motifs
  // (convergence typically takes 4-5 iterations, but we run a few extra to be safe)

  for (i = 0; i < 10; i++) {

    // Recalculate the RBS motif background
    for (j = 0; j < 28; j++) rbg[j] = 0.0;
    for (j = 0; j < nn; j++) {
      if (nod[j].type == STOP || nod[j].edge == 1) continue;
      if      (tinf->rbs_wt[nod[j].rbs[0]] > tinf->rbs_wt[nod[j].rbs[1]]+1.0 || nod[j].rbs[1] == 0) max_rb = nod[j].rbs[0];
      else if (tinf->rbs_wt[nod[j].rbs[0]] < tinf->rbs_wt[nod[j].rbs[1]]-1.0 || nod[j].rbs[0] == 0) max_rb = nod[j].rbs[1];
      else max_rb = (int) dmax(nod[j].rbs[0], nod[j].rbs[1]);
      rbg[max_rb] += 1.0;
    }

  // Debug statement
  if (0) {
    Rcout << "Iteration " << i << ":  rbg" << std::endl;
    for (j = 0; j < 28; j++) {
      Rcout << "  " << rbg[j];
    }
    Rcout << std::endl;
  }
    sum = 0.0;
    for (j = 0; j < 28; j++) sum += rbg[j];
    for (j = 0; j < 28; j++) rbg[j] /= sum;

    for (j = 0; j < 28; j++) rreal[j] = 0.0;
    for (j = 0; j < 3 ; j++) treal[j] = 0.0;

    // Forward strand pass
    for (j = 0; j < 3; j++) {
      best[j] = 0.0;
      bndx[j] = -1;
      rbs[j]  = 0;
      type[j] = 0;
    }
    for (j = 0; j < nn; j++) {
      if(nod[j].type != STOP && nod[j].edge == 1) continue;
      fr = (nod[j].ndx)%3;
      if (nod[j].type == STOP && nod[j].strand == 1) {
        if (best[fr] >= sthresh && nod[bndx[fr]].ndx%3 == fr) {
          rreal[rbs[fr]]  += 1.0;
          treal[type[fr]] += 1.0;
          if (i == 9)
            count_upstream_composition(seq, slen, 1, nod[bndx[fr]].ndx, tinf);
        }
        best[fr] = 0.0;
        bndx[fr] = -1;
        rbs[fr]  = 0;
        type[fr] = 0;
      }
      else if (nod[j].strand == 1) {
        if      (tinf->rbs_wt[nod[j].rbs[0]] > tinf->rbs_wt[nod[j].rbs[1]]+1.0 || nod[j].rbs[1] == 0) max_rb = nod[j].rbs[0];
        else if (tinf->rbs_wt[nod[j].rbs[0]] < tinf->rbs_wt[nod[j].rbs[1]]-1.0 || nod[j].rbs[0] == 0) max_rb = nod[j].rbs[1];
        else max_rb = (int) dmax(nod[j].rbs[0], nod[j].rbs[1]);
        if (nod[j].cscore + wt*tinf->rbs_wt[max_rb] + wt*tinf->type_wt[nod[j].type] >= best[fr]) {
          best[fr] = nod[j].cscore + wt*tinf->rbs_wt[max_rb];
          best[fr] += wt*tinf->type_wt[nod[j].type];
          bndx[fr] = j;
          type[fr] = nod[j].type;
          rbs[fr]  = max_rb;
        }
      }
    }

    // Reverse strand pass
    for (j = 0; j < 3; j++) {
      best[j] = 0.0;
      bndx[j] = -1;
      rbs[j]  = 0;
      type[j] = 0;
    }
    for (j = nn-1; j >= 0; j--) {
      if(nod[j].type != STOP && nod[j].edge == 1) continue;
      fr = (nod[j].ndx)%3;
      if (nod[j].type == STOP && nod[j].strand == -1) {
        if (best[fr] >= sthresh && nod[bndx[fr]].ndx%3 == fr) {
          rreal[rbs[fr]]  += 1.0;
          treal[type[fr]] += 1.0;
          if(i == 9)
            count_upstream_composition(rseq, slen, -1, nod[bndx[fr]].ndx, tinf);
        }
        best[fr] = 0.0;
        bndx[fr] = -1;
        rbs[fr]  = 0;
        type[fr] = 0;
      }
      else if (nod[j].strand == -1) {
        if      (tinf->rbs_wt[nod[j].rbs[0]] > tinf->rbs_wt[nod[j].rbs[1]]+1.0 || nod[j].rbs[1] == 0) max_rb = nod[j].rbs[0];
        else if (tinf->rbs_wt[nod[j].rbs[0]] < tinf->rbs_wt[nod[j].rbs[1]]-1.0 || nod[j].rbs[0] == 0) max_rb = nod[j].rbs[1];
        else max_rb = (int) dmax(nod[j].rbs[0], nod[j].rbs[1]);
        if (nod[j].cscore + wt*tinf->rbs_wt[max_rb] + wt*tinf->type_wt[nod[j].type] >= best[fr]) {
          best[fr] = nod[j].cscore + wt*tinf->rbs_wt[max_rb];
          best[fr] += wt*tinf->type_wt[nod[j].type];
          bndx[fr] = j;
          type[fr] = nod[j].type;
          rbs[fr]  = max_rb;
        }
      }
    }

  // Debug statement
  if (0) {
    Rcout << "Iteration " << i << ":  rreal" << std::endl;
    for (j = 0; j < 28; j++) {
      Rcout << "  " << rreal[j];
    }
    Rcout << std::endl;
  }

    sum = 0.0;
    for (j = 0; j < 28; j++)
      sum += rreal[j];

    if (sum == 0.0)
      for (j = 0; j < 28; j++) tinf->rbs_wt[j] = 0.0;
    else {
      for (j = 0; j < 28; j++) {
        rreal[j] /= sum;
        if (rbg[j] != 0) tinf->rbs_wt[j] = log(rreal[j]/rbg[j]);
        else             tinf->rbs_wt[j] = -4.0;
        if (tinf->rbs_wt[j] >  4.0) tinf->rbs_wt[j] =  4.0;
        if (tinf->rbs_wt[j] < -4.0) tinf->rbs_wt[j] = -4.0;
      }
    }

    sum = 0.0;
    for (j = 0; j < 3; j++)
      sum += treal[j];

    if (sum == 0.0)
      for (j = 0; j < 3; j++) tinf->type_wt[j] = 0.0;
    else {
      for (j = 0; j < 3; j++) {
        treal[j] /= sum;
        if (tbg[j] != 0) tinf->type_wt[j] = log(treal[j]/tbg[j]);
        else             tinf->type_wt[j] = -4.0;
        if (tinf->type_wt[j] >  4.0) tinf->type_wt[j] =  4.0;
        if (tinf->type_wt[j] < -4.0) tinf->type_wt[j] = -4.0;
      }
    }
    if (sum <= (double)nn/2000.0) sthresh /= 2.0;


  // Debug statement
  if (0) {
    Rcout << "Iteration " << i << std::endl;
    for (j = 0; j < 28; j++) {
      Rcout << "   " << tinf->rbs_wt[j];
    }
    Rcout << std::endl;
  }

  }

  // Convert upstream base composition to a log score
  for (i = 0; i < 32; i++) {
    sum = 0.0;
    for (j = 0; j < 4; j++)
      sum += tinf->ups_comp[i][j];

    if (sum == 0.0)
      for (j = 0; j < 4; j++) tinf->ups_comp[i][j] = 0.0;
    else {
      for (j = 0; j < 4; j++) {
        tinf->ups_comp[i][j] /= sum;
        if (tinf->gc > 0.1 && tinf->gc < 0.9) {
          if (j == 0 || j == 3) tinf->ups_comp[i][j] = log(tinf->ups_comp[i][j]*2.0/(1.0-tinf->gc));
          else                  tinf->ups_comp[i][j] = log(tinf->ups_comp[i][j]*2.0/tinf->gc);
        }
        else if (tinf->gc <= 0.1) {
          if (j == 0 || j == 3) tinf->ups_comp[i][j] = log(tinf->ups_comp[i][j]*2.0/0.90);
          else                  tinf->ups_comp[i][j] = log(tinf->ups_comp[i][j]*2.0/0.10);
        }
        else {
          if (j == 0 || j == 3) tinf->ups_comp[i][j] = log(tinf->ups_comp[i][j]*2.0/0.10);
          else                  tinf->ups_comp[i][j] = log(tinf->ups_comp[i][j]*2.0/0.90);
        }
        if (tinf->ups_comp[i][j] >  4.0) tinf->ups_comp[i][j] =  4.0;
        if (tinf->ups_comp[i][j] < -4.0) tinf->ups_comp[i][j] = -4.0;
      }    
    }
  }
}




void determine_sd_usage(class _training *tinf) {

  tinf->uses_sd = 1;

  if (tinf->rbs_wt[0] >= 0.0) tinf->uses_sd = 0;
  if (  tinf->rbs_wt[16] < 1.0 &&
        tinf->rbs_wt[13] < 1.0 &&
        tinf->rbs_wt[15] < 1.0 &&
       (tinf->rbs_wt[0] >= -0.5 || (tinf->rbs_wt[22] < 2.0 && tinf->rbs_wt[24] < 2.0 && tinf->rbs_wt[27] < 2.0))
     )
    tinf->uses_sd = 0;
}






void find_best_upstream_motif(class _training *tinf, char *seq, char *rseq, int slen, class _node *nod, int stage) {
   
  // Given the weights for various motifs/distances from the training file, return the highest scoring mer/spacer
  // combination of 3-6bp motifs with a spacer ranging from 3bp to 15bp.  In the final stage of start training, only
  // good scoring motifs are returned.
   
  int i,
      j,
      start,
      spacer,
      spacendx,
      index;
  int max_spacer = 0,
      max_spacendx = 0,
      max_len = 0,
      max_ndx = 0;
   
  double max_sc = -100.0,
         score = 0.0;
   
  char *wseq;
   
  if (nod->type == STOP || nod->edge == 1) return;
  if (nod->strand == 1) {
    wseq = seq;
    start = nod->ndx;
  }
  else {
    wseq = rseq;
    start = slen-1-nod->ndx;
  }
   
  for (i = 3; i >= 0; i--) {
    for (j = start-18-i; j <= start-6-i; j++) {
      if (j < 0) continue;
      spacer = start-j-i-3;
      if      (j <= start-16-i) spacendx = 3;
      else if (j <= start-14-i) spacendx = 2;
      else if (j >= start -7-i) spacendx = 1;
      else spacendx = 0;
      index = mer_ndx(i+3, wseq, j);
      score = tinf->mot_wt[i][spacendx][index];
      if(score > max_sc) {
        max_sc = score;
        max_spacendx = spacendx;
        max_spacer = spacer;
        max_ndx = index;
        max_len = i+3;
      }
    }
  }
   
  if(stage == 2 && (max_sc == -4.0 || max_sc < tinf->no_mot + 0.69)) {
    nod->mot.ndx = 0;
    nod->mot.len = 0;
    nod->mot.spacendx = 0;
    nod->mot.spacer = 0;
    nod->mot.score = tinf->no_mot;
  }
  else {
    nod->mot.ndx = max_ndx;
    nod->mot.len = max_len;
    nod->mot.spacendx = max_spacendx;
    nod->mot.spacer = max_spacer;
    nod->mot.score = max_sc;
  }
}







void update_motif_counts(double mcnt[4][4][4096], double *zero, char *seq, char *rseq, int slen, class _node *nod, int stage) {

  // Update the motif counts from a putative quote(real) start.  This is done in three stages.
  // In stage 0, all motifs sizes 3-6bp in the region with spacer 3-15bp are counted.
  // In stage 1, only the best motif and all its subsets are counted
  //   (e.g. for AGGAG, we would count AGGAG, AGGA, GGAG, AGG, GGA, and GAG).
  // In stage 2, only the best single motif is counted.

  int i,
      j,
      k,
      start,
      spacendx;

  char *wseq;

  class _motif *mot = &(nod->mot);

  if (nod->type == STOP || nod->edge == 1) return;
  if (mot->len == 0) {
    *zero += 1.0;
    return;
  }
   
  if (nod->strand == 1) { wseq =  seq; start = nod->ndx;        }
  else                  { wseq = rseq; start = slen-1-nod->ndx; }
   
  // Stage 0:  Count all motifs.  If a motif is detected, it is counted for every distance in stage 0.
  // This is done to make sure off-distance good motifs are recognized.

  if (stage == 0) {
    for (i = 3; i >= 0; i--) {
      for (j = start-18-i; j <= start-6-i; j++) {
        if (j < 0) continue;
        if      (j <= start-16-i) spacendx = 3;
        else if (j <= start-14-i) spacendx = 2;
        else if (j >= start -7-i) spacendx = 1;
        else spacendx = 0;
        for (k = 0; k < 4; k++)
          mcnt[i][k][mer_ndx(i+3, wseq, j)] += 1.0;
      }
    }
  }
   
  // Stage 1:  Count only the best motif, but also count all its sub-motifs.

  else if (stage == 1) {
    mcnt[mot->len-3][mot->spacendx][mot->ndx] += 1.0;
    for (i = 0; i < mot->len-3; i++) {
      for (j = start-(mot->spacer)-(mot->len); j <= start-(mot->spacer)-(i+3); j++) {
        if (j < 0) continue;
        if      (j <= start-16-i) spacendx = 3;
        else if (j <= start-14-i) spacendx = 2;
        else if (j >= start -7-i) spacendx = 1;
        else spacendx = 0;
        mcnt[i][spacendx][mer_ndx(i+3, wseq, j)] += 1.0;
      }
    }
  }
   
  // Stage 2:  Only count the highest scoring motif.

  else if (stage == 2)
    mcnt[mot->len-3][mot->spacendx][mot->ndx] += 1.0;
}







void build_coverage_map(double real[4][4][4096], int good[4][4][4096], double ng, int stage) {

  // In addition to log likelihood, we also require a motif to actually be present a good portion of the time
  // in an absolute sense across the genome.  The coverage map is just a numerical map of whether or not to accept
  // a putative motif as a real one (despite its log likelihood score.  A motif is considered quote(good)
  // if it contains a 3-base subset of itself that is present in at least 20% of the total genes.
  // In the final stage of iterative start training, all motifs are labeled good.  0 = bad, 1 = good, 2 = good w/mismatch.

  int i,
      j,
      k,
      l,
      tmp,
      decomp[3];
   
  double thresh = 0.2;
   
  for (i = 0; i < 4; i++)
    for (j = 0; j < 4; j++)
      for (k = 0; k < 4096; k++)
        good[i][j][k] = 0;
   
  // 3-base motifs
  for (i = 0; i < 4; i++)
    for (j = 0; j < 64; j++) {
    if (real[0][i][j]/ng >= thresh) {
      for (k = 0; k < 4; k++)
        good[0][k][j] = 1;
      }
    }
   
  // 4-base motifs, must contain two valid 3-base motifs
  for (i = 0; i < 4; i++)
    for (j = 0; j < 256; j++) {
      decomp[0] = (j&252)>>2;
      decomp[1] = j&63;
      if (good[0][i][decomp[0]] == 0 || good[0][i][decomp[1]] == 0) continue;
      good[1][i][j] = 1;
    }
   
  // 5-base motifs, interior mismatch allowed only if entire 5-base motif represents 3 valid 3-base motifs (if mismatch converted)
  for (i = 0; i < 4; i++)
    for (j = 0; j < 1024; j++) {
      decomp[0] = (j&1008)>>4;
      decomp[1] = (j&252)>>2;
      decomp[2] = j&63;
      if (good[0][i][decomp[0]] == 0 || good[0][i][decomp[1]] == 0 || good[0][i][decomp[2]] == 0) continue;
      good[2][i][j] = 1;
      tmp = j;
      for (k = 0; k <= 16; k+= 16) {
        tmp = tmp ^ k;
        for (l = 0; l <= 32; l+= 32) {
          tmp = tmp ^ l;
          if (good[2][i][tmp] == 0) good[2][i][tmp] = 2;
        }
      }
    }
   
  // 6-base motifs, must contain two valid 5-base motifs
  for (i = 0; i < 4; i++)
    for (j = 0; j < 4096; j++) {
      decomp[0] = (j&4092)>>2;
      decomp[1] = j&1023;
      if (good[2][i][decomp[0]] == 0 || good[2][i][decomp[1]] == 0) continue;
      if (good[2][i][decomp[0]] == 1 && good[2][i][decomp[1]] == 1) good[3][i][j] = 1;
      else                                                          good[3][i][j] = 2;
  }
   
}






void train_starts_nonsd(char *seq, char *rseq, int slen, class _node *nod, int nn, class _training *tinf) {
   
  int i,
      j,
      k,
      l,
      fr,
      bndx[3],
      mgood[4][4][4096],
      stage;
   
  double sum,
         ngenes,
         wt = tinf->st_wt,
         best[3],
         sthresh = 35.0;
  double tbg[3],
         treal[3];
  double mbg[4][4][4096],
         mreal[4][4][4096],
         zbg,
         zreal;
   
  for (i = 0; i < 32; i++)
    for (j = 0; j < 4; j++)
      tinf->ups_comp[i][j] = 0.0;
   
  // Build the background of random types
  for (i = 0; i < 3; i++) tinf->type_wt[i] = 0.0;
  for (i = 0; i < 3; i++) tbg[i] = 0.0;
  for (i = 0; i < nn; i++) {
    if (nod[i].type == STOP) continue;
    tbg[nod[i].type] += 1.0;
  }
  sum = 0.0;
  for (i = 0; i < 3; i++) sum += tbg[i];
  for (i = 0; i < 3; i++) tbg[i] /= sum;

  // Iterate 20 times through the list of nodes. Converge upon optimal weights for ATG vs GTG vs TTG and RBS motifs.
  // (convergence typically takes 4-5 iterations, but we run a few extra to be safe)

  for(i = 0; i < 20; i++) {

    // Determine which stage of motif finding we are in
    if      (i < 4 ) stage = 0;
    else if (i < 12) stage = 1;
    else stage = 2;

    // Recalculate the upstream motif background and set quote(real) counts to 0
    for (j = 0; j < 4; j++)
      for (k = 0; k < 4; k++)
        for (l = 0; l < 4096; l++)
          mbg[j][k][l] = 0.0;

    zbg = 0.0;
    for (j = 0; j < nn; j++) {
      if (nod[j].type == STOP || nod[j].edge == 1) continue;
      find_best_upstream_motif(tinf, seq, rseq, slen, &nod[j], stage);
      update_motif_counts(mbg, &zbg, seq, rseq, slen, &(nod[j]), stage);
    }

    sum = 0.0;
    for (j = 0; j < 4; j++)
      for (k = 0; k < 4; k++)
        for (l = 0; l < 4096; l++)
          sum += mbg[j][k][l];
    sum += zbg;

    for (j = 0; j < 4; j++)
      for (k = 0; k < 4; k++)
        for (l = 0; l < 4096; l++)
          mbg[j][k][l] /= sum;
    zbg /= sum;

    // Reset counts of quote(real) motifs/types to 0
    for (j = 0; j < 4; j++)
      for (k = 0; k < 4; k++)
        for (l = 0; l < 4096; l++)
          mreal[j][k][l] = 0.0;
    zreal = 0.0;

    for (j = 0; j < 3; j++)
      treal[j] = 0.0;
    ngenes = 0.0;

    // Forward strand pass
    for (j = 0; j < 3; j++ ) {
      best[j] = 0.0;
      bndx[j] = -1;
    }
    for(j = 0; j < nn; j++) {
      if (nod[j].type != STOP && nod[j].edge == 1) continue;
      fr = (nod[j].ndx)%3;
      if (nod[j].type == STOP && nod[j].strand == 1) {
        if (best[fr] >= sthresh) {
          ngenes += 1.0;
          treal[nod[bndx[fr]].type] += 1.0;
          update_motif_counts(mreal, &zreal, seq, rseq, slen, &(nod[bndx[fr]]), stage);
          if (i == 19) count_upstream_composition(seq, slen, 1, nod[bndx[fr]].ndx, tinf);
        }
        best[fr] = 0.0;
        bndx[fr] = -1;
      }
      else if(nod[j].strand == 1) {
        if(nod[j].cscore + wt*nod[j].mot.score + wt*tinf->type_wt[nod[j].type] >= best[fr]) {
          best[fr] = nod[j].cscore + wt*nod[j].mot.score;
          best[fr] += wt*tinf->type_wt[nod[j].type];
          bndx[fr] = j;
        }
      }
    }

    // Reverse strand pass
    for (j = 0; j < 3; j++) {
      best[j] = 0.0;
      bndx[j] = -1;
    }
    for (j = nn-1; j >= 0; j--) {
      if (nod[j].type != STOP && nod[j].edge == 1) continue;
      fr = (nod[j].ndx)%3;
      if (nod[j].type == STOP && nod[j].strand == -1) {
        if (best[fr] >= sthresh) {
          ngenes += 1.0;
          treal[nod[bndx[fr]].type] += 1.0;
          update_motif_counts(mreal, &zreal, seq, rseq, slen, &(nod[bndx[fr]]), stage);
          if (i == 19) count_upstream_composition(rseq, slen, -1, nod[bndx[fr]].ndx, tinf);
        }
        best[fr] = 0.0;
        bndx[fr] = -1;
      }
      else if (nod[j].strand == -1) {
        if (nod[j].cscore + wt*nod[j].mot.score + wt*tinf->type_wt[nod[j].type] >= best[fr]) {
          best[fr] = nod[j].cscore + wt*nod[j].mot.score;
          best[fr] += wt*tinf->type_wt[nod[j].type];
          bndx[fr] = j;
        }
      }
    }

    // Update the log likelihood weights for type and RBS motifs
    if (stage < 2) build_coverage_map(mreal, mgood, ngenes, stage);
    sum = 0.0;
    for (j = 0; j < 4; j++)
      for (k = 0; k < 4; k++)
        for( l = 0; l < 4096; l++)
          sum += mreal[j][k][l];
    sum += zreal;

    if(sum == 0.0) {
      for (j = 0; j < 4; j++)
        for (k = 0; k < 4; k++)
          for (l = 0; l < 4096; l++)
            tinf->mot_wt[j][k][l] = 0.0;
      tinf->no_mot = 0.0;
    }
    else {
      for (j = 0; j < 4; j++)
        for (k = 0; k < 4; k++)
          for (l = 0; l < 4096; l++) {{{
            if (mgood[j][k][l] == 0) {
              zreal += mreal[j][k][l];
              zbg += mreal[j][k][l];
              mreal[j][k][l] = 0.0;
              mbg[j][k][l] = 0.0;
            }
            mreal[j][k][l] /= sum;
            if (mbg[j][k][l] != 0) tinf->mot_wt[j][k][l] = log(mreal[j][k][l]/mbg[j][k][l]);
            else                   tinf->mot_wt[j][k][l] = -4.0;
            if (tinf->mot_wt[j][k][l] >  4.0) tinf->mot_wt[j][k][l] =  4.0;
            if (tinf->mot_wt[j][k][l] < -4.0) tinf->mot_wt[j][k][l] = -4.0;
          }}}
    }
    zreal /= sum;

    if (zbg != 0) tinf->no_mot = log(zreal/zbg);
    else          tinf->no_mot = -4.0;
    if (tinf->no_mot >  4.0) tinf->no_mot =  4.0;
    if (tinf->no_mot < -4.0) tinf->no_mot = -4.0;
    sum = 0.0;

    for (j = 0; j < 3; j++)
      sum += treal[j];
    if (sum == 0.0)
      for (j = 0; j < 3; j++)
        tinf->type_wt[j] = 0.0;
    else {
      for(j = 0; j < 3; j++) {
        treal[j] /= sum;
        if (tbg[j] != 0) tinf->type_wt[j] = log(treal[j]/tbg[j]);
        else             tinf->type_wt[j] = -4.0;
        if (tinf->type_wt[j] >  4.0) tinf->type_wt[j] =  4.0;
        if (tinf->type_wt[j] < -4.0) tinf->type_wt[j] = -4.0;
      }
    }
    if (sum <= (double)nn/2000.0) sthresh /= 2.0;
  }

  // Convert upstream base composition to a log score
  for (i = 0; i < 32; i++) {
    sum = 0.0;
    for (j = 0; j < 4; j++) sum += tinf->ups_comp[i][j];
    if (sum == 0.0)
      for (j = 0; j < 4; j++)
        tinf->ups_comp[i][j] = 0.0;
    else {
      for (j = 0; j < 4; j++) {
        tinf->ups_comp[i][j] /= sum;
        if (tinf->gc > 0.1 && tinf->gc < 0.9) {
          if (j == 0 || j == 3) tinf->ups_comp[i][j] = log(tinf->ups_comp[i][j]*2.0/(1.0-tinf->gc));
          else                  tinf->ups_comp[i][j] = log(tinf->ups_comp[i][j]*2.0/tinf->gc);
        }
        else if(tinf->gc <= 0.1) {
          if (j == 0 || j == 3) tinf->ups_comp[i][j] = log(tinf->ups_comp[i][j]*2.0/0.90);
          else                  tinf->ups_comp[i][j] = log(tinf->ups_comp[i][j]*2.0/0.10);
        }
        else {
          if (j == 0 || j == 3) tinf->ups_comp[i][j] = log(tinf->ups_comp[i][j]*2.0/0.10);
          else                  tinf->ups_comp[i][j] = log(tinf->ups_comp[i][j]*2.0/0.90);
        }
        if (tinf->ups_comp[i][j] >  4.0) tinf->ups_comp[i][j] =  4.0;
        if (tinf->ups_comp[i][j] < -4.0) tinf->ups_comp[i][j] = -4.0;
      }
    }
  }

}





void calc_orf_gc(char *seq, char *rseq, int slen, class _node *nod, int nn, class _training *tinf) {

  // *** Calculate the GC Content for each start-stop pair ***

  int i,
      j,
      last[3],
      fr;

  double gc[3],
         gsize = 0.0;

  // Go through each start-stop pair and calculate the %GC of the gene

  for (i = 0; i < 3; i++)
    gc[i] = 0.0;

  for (i = nn-1; i >= 0; i--) {
    fr = (nod[i].ndx)%3;
    if (nod[i].strand == 1 && nod[i].type == STOP) {
      last[fr] = nod[i].ndx;

      // gc[fr] = is_gc(seq, nod[i].ndx) + is_gc(seq, nod[i].ndx+1) + is_gc(seq, nod[i].ndx+2);
      gc[fr] = 0.0;
      if ((strncmp(&seq[nod[i].ndx  ], "G", 1) == 0) || (strncmp(&seq[nod[i].ndx  ], "C", 1) == 0)) gc[fr]++;
      if ((strncmp(&seq[nod[i].ndx+1], "G", 1) == 0) || (strncmp(&seq[nod[i].ndx+1], "C", 1) == 0)) gc[fr]++;
      if ((strncmp(&seq[nod[i].ndx+2], "G", 1) == 0) || (strncmp(&seq[nod[i].ndx+2], "C", 1) == 0)) gc[fr]++;
    }
    else if (nod[i].strand == 1) {
      for (j = last[fr]-3; j >= nod[i].ndx; j-=3) {
        // gc[fr] += is_gc(seq, j) + is_gc(seq, j+1) + is_gc(seq, j+2);
        if ((strncmp(&seq[j  ], "G", 1) == 0) || (strncmp(&seq[j  ], "C", 1) == 0)) gc[fr]++;
        if ((strncmp(&seq[j+1], "G", 1) == 0) || (strncmp(&seq[j+1], "C", 1) == 0)) gc[fr]++;
        if ((strncmp(&seq[j+2], "G", 1) == 0) || (strncmp(&seq[j+2], "C", 1) == 0)) gc[fr]++;
      }
      gsize = (float)(abs(nod[i].stop_val-nod[i].ndx)+3.0);
      nod[i].gc_cont = gc[fr]/gsize;
      last[fr] = nod[i].ndx;
    }
  }

  for(i = 0; i < 3; i++)
    gc[i] = 0.0;

  for(i = 0; i < nn; i++) {
    fr = (nod[i].ndx)%3;
    if(nod[i].strand == -1 && nod[i].type == STOP) {
      last[fr] = nod[i].ndx;

      // gc[fr] = is_gc(seq, nod[i].ndx) + is_gc(seq, nod[i].ndx-1) + is_gc(seq, nod[i].ndx-2);
      gc[fr] = 0.0;
      if ((strncmp(&seq[nod[i].ndx  ], "G", 1) == 0) || (strncmp(&seq[nod[i].ndx  ], "C", 1) == 0)) gc[fr]++;
      if ((strncmp(&seq[nod[i].ndx-1], "G", 1) == 0) || (strncmp(&seq[nod[i].ndx-1], "C", 1) == 0)) gc[fr]++;
      if ((strncmp(&seq[nod[i].ndx-2], "G", 1) == 0) || (strncmp(&seq[nod[i].ndx-2], "C", 1) == 0)) gc[fr]++;
    }
    else if (nod[i].strand == -1) {
      for (j = last[fr]+3; j <= nod[i].ndx; j+=3) {
        // gc[fr] += is_gc(seq, j) + is_gc(seq, j+1) + is_gc(seq, j+2);
        if ((strncmp(&seq[j  ], "G", 1) == 0) || (strncmp(&seq[j  ], "C", 1) == 0)) gc[fr]++;
        if ((strncmp(&seq[j+1], "G", 1) == 0) || (strncmp(&seq[j+1], "C", 1) == 0)) gc[fr]++;
        if ((strncmp(&seq[j+2], "G", 1) == 0) || (strncmp(&seq[j+2], "C", 1) == 0)) gc[fr]++;
      }
      gsize = (float)(abs(nod[i].stop_val-nod[i].ndx)+3.0);
      nod[i].gc_cont = gc[fr]/gsize;
      last[fr] = nod[i].ndx;
    }
  }
}






void raw_coding_score(char *seq, char *rseq, int slen, class _node *nod, int nn, class _training *tinf) {

  // *** Score coding for each candidate.  We also sharpen coding/noncoding thresholds to prevent choosing
  //     interior starts when there is strong coding continuing upstream. ***

  int i,
      j,
      last[3],
      fr;

  double score[3],
         lfac,
         no_stop,
         gsize = 0.0;

  // Computing stop information to be used in the Third Pass below.
  // The original C implemention considered translation other than 11, where TGA and TAG are not stops.
  // This code assumes translation table 11.

  no_stop  = ((1-tinf->gc)*(1-tinf->gc)*tinf->gc)/4.0;
  no_stop += ((1-tinf->gc)*(1-tinf->gc)*(1-tinf->gc))/8.0;
  no_stop  = (1 - no_stop);

  // Initial Pass: Score coding potential (start->stop)

  for (i = 0; i < 3; i++)
    score[i] = 0.0;
  for (i = nn-1; i >= 0; i--) {
    fr = (nod[i].ndx)%3;
    if (nod[i].strand == 1 && nod[i].type == STOP) {
      last[fr] = nod[i].ndx;
      score[fr] = 0.0;
    }
    else if (nod[i].strand == 1) {
      for (j = last[fr]-3; j >= nod[i].ndx; j-=3)                  {
        score[fr] += tinf->gene_dc[mer_ndx(6, seq, j)];
if (0) {
  if (nod[i].ndx == 19741) {
    Rcout << "      j: " << j << "   " << mer_ndx(6, seq, j) << "   " << tinf->gene_dc[mer_ndx(6, seq, j)] << std::endl;
  }
}
                                                                   }
      nod[i].cscore = score[fr];
      last[fr] = nod[i].ndx;
    }
if (0) {
  if (nod[i].ndx == 19741) {
    Rcout << "1a: " << nod[i].cscore << std::endl;
    Rcout << "  fr: " << fr << "   score[fr]: " << score[fr] << std::endl;
    Rcout << "  i: " << i << std::endl;
  }
}
  }

  for (i = 0; i < 3; i++)
    score[i] = 0.0;
  for(i = 0; i < nn; i++) {
    fr = (nod[i].ndx)%3;
    if (nod[i].strand == -1 && nod[i].type == STOP) {
      last[fr] = nod[i].ndx;
      score[fr] = 0.0;
    }
    else if (nod[i].strand == -1) {
      for (j = last[fr]+3; j <= nod[i].ndx; j+=3)
        score[fr] += tinf->gene_dc[mer_ndx(6, rseq, slen-j-1)];
      nod[i].cscore = score[fr];
      last[fr] = nod[i].ndx;
    }
if (0) {
  if (nod[i].ndx == 19741) {
    Rcout << "1b: " << nod[i].cscore << std::endl;
    Rcout << "  fr: " << fr << "   score[fr]: " << score[fr] << std::endl;
  }
}
  }

  // Second Pass: Penalize start nodes with ascending coding to their left

  for (i = 0; i < 3; i++)
    score[i] = -10000.0;
  for (i = 0; i < nn; i++) {
    fr = (nod[i].ndx)%3;
    if (nod[i].strand == 1 && nod[i].type == STOP)
      score[fr] = -10000.0;
    else if(nod[i].strand == 1) {
      if (nod[i].cscore > score[fr])
        score[fr] = nod[i].cscore;
      else nod[i].cscore -= (score[fr] - nod[i].cscore);
    }
if (0) {
  if (nod[i].ndx == 19741) {
    Rcout << "2a: " << nod[i].cscore << std::endl;
    Rcout << "  fr: " << fr << "   score[fr]: " << score[fr] << std::endl;
  }
}
  }
  for (i = 0; i < 3; i++)
    score[i] = -10000.0;
  for (i = nn-1; i >= 0; i--) {
    fr = (nod[i].ndx)%3;
    if (nod[i].strand == -1 && nod[i].type == STOP)
      score[fr] = -10000.0;
    else if(nod[i].strand == -1) {
      if (nod[i].cscore > score[fr])
        score[fr] = nod[i].cscore;
      else nod[i].cscore -= (score[fr] - nod[i].cscore);
    }
if (0) {
  if (nod[i].ndx == 19741) {
    Rcout << "2b: " << nod[i].cscore << std::endl;
    Rcout << "  fr: " << fr << "   score[fr]: " << score[fr] << std::endl;
  }
}
  }

  // Third Pass: Add length-based factor to the score
  // Penalize start nodes based on length to their left

  for (i = 0; i < nn; i++) {
    fr = (nod[i].ndx)%3;
    if (nod[i].strand == 1 && nod[i].type == STOP)
      score[fr] = -10000.0;
    else if (nod[i].strand == 1) {
      gsize = ((float)(abs(nod[i].stop_val-nod[i].ndx)+3.0))/3.0;
      if (gsize > 1000.0) {
        lfac  = log((1-pow(no_stop, 1000.0))/pow(no_stop, 1000.0));
        lfac -= log((1-pow(no_stop,   80.0))/pow(no_stop,   80.0));
        lfac *= (gsize - 80.0) / 920.0;
      }
      else {
        lfac  = log((1-pow(no_stop, gsize))/pow(no_stop, gsize));
        lfac -= log((1-pow(no_stop,  80.0))/pow(no_stop,  80.0));
      }
      if (lfac > score[fr])
        score[fr] = lfac;
      else lfac -= dmax(dmin(score[fr] - lfac, lfac), 0);
      if (lfac > 3.0 && nod[i].cscore < 0.5*lfac)
        nod[i].cscore = 0.5*lfac;
      nod[i].cscore += lfac;
    }
if (0) {
  if (nod[i].ndx == 19741) {
    Rcout << "3a: " << nod[i].cscore << std::endl;
    Rcout << "  fr: " << fr << "   score[fr]: " << score[fr] << std::endl;
  }
}
  }
  for (i = nn-1; i >= 0; i--) {
    fr = (nod[i].ndx)%3;
    if (nod[i].strand == -1 && nod[i].type == STOP)
      score[fr] = -10000.0;
    else if (nod[i].strand == -1) {
      gsize = ((float)(abs(nod[i].stop_val-nod[i].ndx)+3.0))/3.0;
      if (gsize > 1000.0) {
        lfac  = log((1-pow(no_stop, 1000.0))/pow(no_stop, 1000.0));
        lfac -= log((1-pow(no_stop,   80.0))/pow(no_stop,   80.0));
        lfac *= (gsize - 80.0) / 920.0;
      }
      else {
        lfac  = log((1-pow(no_stop, gsize))/pow(no_stop, gsize));
        lfac -= log((1-pow(no_stop,  80.0))/pow(no_stop,  80.0));
      }
      if (lfac > score[fr])
        score[fr] = lfac;
      else lfac -= dmax(dmin(score[fr] - lfac, lfac), 0);
      if (lfac > 3.0 && nod[i].cscore < 0.5*lfac)
        nod[i].cscore = 0.5*lfac;
      nod[i].cscore += lfac;
    }
if (0) {
  if (nod[i].ndx == 19741) {
    Rcout << "3b: " << nod[i].cscore << std::endl;
    Rcout << "  fr: " << fr << "   score[fr]: " << score[fr] << std::endl;
  }
}
  }

}







void score_upstream_composition(char *seq, int slen, class _node *nod, class _training *tinf) {

// For a given start, score the base composition of the upstream region at positions -1 and -2 and -15 to -44.
// This will be used to supplement the SD (or other) motif finder with additional information.

  int i,
      start,
      count = 0;

  if (nod->strand == 1) start =        nod->ndx;
  else                  start = slen-1-nod->ndx;

  nod->uscore = 0.0;

  for (i = 1; i < 45; i++) {
    if (i > 2 && i < 15) continue;
    if (start-i < 0) continue;
    nod->uscore += 0.4 * tinf->st_wt * tinf->ups_comp[count][mer_ndx(1, seq, start-i)];

if (0) {
  if (nod->ndx == 16123) {
    Rcout << "  i: " << i << "   ups_comp: " << tinf->ups_comp[count][mer_ndx(1, seq, start-i)] << "   uscore: " << nod->uscore << std::endl;
  }
}
    count++;
  }
}







void score_nodes(char *seq, char *rseq, int slen, class _node *nod, int nn, class _training *tinf) {

  int i,
      j;

  double negf,
         posf,
         rbs1,
         rbs2,
         sd_score,
         edge_gene;

  // Step 1: Calculate raw coding potential for every start-stop pair.

  calc_orf_gc     (seq, rseq, slen, nod, nn, tinf);
Rcout << "Calling raw_coding_score from score_nodes" << std::endl;
  raw_coding_score(seq, rseq, slen, nod, nn, tinf);


  // Step 2: Calculate raw RBS Scores for every start node.

  if (tinf->uses_sd == 1)
    rbs_score(seq, rseq, slen, nod, nn, tinf);
  else {
    for (i = 0; i < nn; i++) {
      if (nod[i].type == STOP || nod[i].edge == 1) continue;
      find_best_upstream_motif(tinf, seq, rseq, slen, &nod[i], 2);
    }
  }

  // Step 3: Score the start nodes

  for (i = 0; i < nn; i++) {

if (0) {
  if (nod[i].ndx == 16123) {
    Rcout << "Location C ... i = " << i << "  ndx = " << nod[i].ndx << "  stop_val = " << nod[i].stop_val << " uscore = " << nod[i].uscore << std::endl;
  }
}
    if (nod[i].type == STOP) continue;

    // Does this gene run off the edge?
    edge_gene = 0;
    if (nod[i].edge == 1) edge_gene++;

    // Additional code at this point in the original C implementation to identify TAG and TGA that are not stops
    // in translation tables other than 11 has been deleted, since this implementation is restricted to table 11.

    // Edge Nodes : stops with no starts, give a small bonus
    if (nod[i].edge == 1) {
        nod[i].tscore = EDGE_BONUS*tinf->st_wt/edge_gene;
        nod[i].uscore = 0.0;
        nod[i].rscore = 0.0;
    }
    else {

      // Type Score
      nod[i].tscore = tinf->type_wt[nod[i].type] * tinf->st_wt;

      // RBS Motif Score
      rbs1 = tinf->rbs_wt[nod[i].rbs[0]];
      rbs2 = tinf->rbs_wt[nod[i].rbs[1]];
      sd_score = dmax(rbs1, rbs2) * tinf->st_wt;
      if (tinf->uses_sd == 1)
        nod[i].rscore = sd_score;
      else {
        nod[i].rscore = tinf->st_wt*nod[i].mot.score;
        if (nod[i].rscore < sd_score && tinf->no_mot > -0.5)
          nod[i].rscore = sd_score;
      }

      // Upstream Score
      if (nod[i].strand == 1)
        score_upstream_composition(seq, slen, &nod[i], tinf);
      else score_upstream_composition(rseq, slen, &nod[i], tinf);

if (0) {
  if (nod[i].ndx == 16123) {
    Rcout << "Location D ... i = " << i << "  ndx = " << nod[i].ndx << "  stop_val = " << nod[i].stop_val << " uscore = " << nod[i].uscore << std::endl;
  }
}


      // Penalize upstream score if choosing this start would stop the gene from running off the edge.
      if      (nod[i].ndx <= 2      && nod[i].strand ==  1) nod[i].uscore += EDGE_UPS * tinf->st_wt;
      else if (nod[i].ndx >= slen-3 && nod[i].strand == -1) nod[i].uscore += EDGE_UPS * tinf->st_wt;
      else if (i < 500 && nod[i].strand == 1) {
        for (j = i-1; j >= 0; j--)
          if (nod[j].edge == 1 && nod[i].stop_val == nod[j].stop_val) {
            nod[i].uscore += EDGE_UPS * tinf->st_wt;
            break;
          }
      }
      else if (i >= nn-500 && nod[i].strand == -1) {
        for (j = i+1; j < nn; j++)
          if (nod[j].edge == 1 && nod[i].stop_val == nod[j].stop_val) {
            nod[i].uscore += EDGE_UPS * tinf->st_wt;
            break;
          }
      }
    }

if (0) {
  if (nod[i].ndx == 16123) {
    Rcout << "Location B ... i = " << i << "  ndx = " << nod[i].ndx << "  stop_val = " << nod[i].stop_val << " uscore = " << nod[i].uscore << std::endl;
  }
}


    // Convert starts at base 1 and slen to edge genes
    if (((nod[i].ndx <= 2      && nod[i].strand ==  1) || 
         (nod[i].ndx >= slen-3 && nod[i].strand == -1)) && nod[i].edge == 0) {   
      edge_gene++;
      nod[i].edge = 1;
      nod[i].tscore = 0.0;
      nod[i].uscore = EDGE_BONUS * tinf->st_wt/edge_gene;
      nod[i].rscore = 0.0;
    }     
            
    // Penalize starts with no stop codon
    if (nod[i].edge == 0 && edge_gene == 1)
      nod[i].uscore -= 0.5 * EDGE_BONUS * tinf->st_wt;
      
    // Penalize non-edge genes < 250bp
    if (edge_gene == 0 && abs(nod[i].ndx-nod[i].stop_val) < 250) {
      negf = 250.0/(float)abs(nod[i].ndx-nod[i].stop_val);
      posf = (float)abs(nod[i].ndx-nod[i].stop_val)/250.0;
      if (nod[i].rscore < 0) nod[i].rscore *= negf;
      if (nod[i].uscore < 0) nod[i].uscore *= negf;
      if (nod[i].tscore < 0) nod[i].tscore *= negf;
      if (nod[i].rscore > 0) nod[i].rscore *= posf;
      if (nod[i].uscore > 0) nod[i].uscore *= posf;
      if (nod[i].tscore > 0) nod[i].tscore *= posf; 
    }
       
    // Additional code for the metagenome case in the original C implementation has been deleted
      
    // Base Start Score
    nod[i].sscore = nod[i].tscore + nod[i].rscore + nod[i].uscore;

    // Debug statement
    if (0) {
      if (nod[i].ndx == 16123) {
        Rcout << "Location A ... i = " << i << "  ndx = " << nod[i].ndx << "  stop_val = " << nod[i].stop_val << " uscore = " << nod[i].uscore << std::endl;
      }
    }
    
    // Penalize starts if coding is negative. Larger penalty for edge genes,
    // since the start is offset by a smaller amount of coding than normal.   
    if (nod[i].cscore < 0.0) {
      if (edge_gene > 0 && nod[i].edge == 0) {
        if (slen > 1500) nod[i].sscore -= tinf->st_wt;
        else             nod[i].sscore -= (10.31 - 0.004 * slen);
      }

      // Additional code for the metagenome case in the original C implementation has been deleted

      else nod[i].sscore -= 0.5;
    }

    // Additional code for the metagenome case in the original C implementation has been deleted

  }


  // Debug statement
  if (0) {
    Rcout << "edge_gene = " << edge_gene << std::endl;
  }
}








void record_overlapping_starts(class _node *nod, int nn, class _training *tinf, int flag) {

  // Since dynamic programming cannot go backwards, we have to record information about overlapping genes
  // in order to build the models.  So, for example, in cases like 5-prime->3-prime, 5-prime-3-prime overlapping
  // on the same strand, we record information about the 2nd 5-prime end under the first 3-prime end information.
  // For every stop, we calculate and store all the best starts that could be used in genes that overlap that 3-prime end.

  int i,
      j;

  double max_sc;

  for (i = 0; i < nn; i++) {
    for (j = 0; j < 3; j++)
      nod[i].star_ptr[j] = -1;
    if (nod[i].type != STOP || nod[i].edge == 1) continue;
    if (nod[i].strand == 1) {
      max_sc = -100;
      for (j = i+3; j >= 0; j--) {
        if (j >= nn || nod[j].ndx > nod[i].ndx+2) continue;
        if (nod[j].ndx + MAX_SAM_OVLP < nod[i].ndx) break;
        if (nod[j].strand == 1 && nod[j].type != STOP) {
          if (nod[j].stop_val <= nod[i].ndx) continue;
          if (flag == 0 && nod[i].star_ptr[(nod[j].ndx)%3] == -1)
            nod[i].star_ptr[(nod[j].ndx)%3] = j;
          else if (flag == 1 && (nod[j].cscore + nod[j].sscore + intergenic_mod(&nod[i], &nod[j], tinf) > max_sc)) {
            nod[i].star_ptr[(nod[j].ndx)%3] = j;
            max_sc = nod[j].cscore + nod[j].sscore + intergenic_mod(&nod[i], &nod[j], tinf);
          }
        }
      }
     }
    else {
      max_sc = -100;
      for (j = i-3; j < nn; j++) {
        if (j < 0 || nod[j].ndx < nod[i].ndx-2) continue;
        if (nod[j].ndx - MAX_SAM_OVLP > nod[i].ndx) break;
        if (nod[j].strand == -1 && nod[j].type != STOP) {
          if (nod[j].stop_val >= nod[i].ndx) continue;
          if (flag == 0 && nod[i].star_ptr[(nod[j].ndx)%3] == -1)
            nod[i].star_ptr[(nod[j].ndx)%3] = j;
          else if (flag == 1 && (nod[j].cscore + nod[j].sscore + intergenic_mod(&nod[j], &nod[i], tinf) > max_sc)) {
            nod[i].star_ptr[(nod[j].ndx)%3] = j;
            max_sc = nod[j].cscore + nod[j].sscore + intergenic_mod(&nod[j], &nod[i], tinf);
          }
        }
      }
    }
  }
}







void eliminate_bad_genes(class _node *nod, int dbeg, class _training *tinf) {

  int path;

  if(dbeg == -1) return;

  path = dbeg;

  while(nod[path].traceb != -1)
    path = nod[path].traceb;

  while(nod[path].tracef != -1) {
    if (nod[path].strand ==  1 && nod[path].type == STOP)  nod[nod[path].tracef].sscore += intergenic_mod(&nod[path], &nod[nod[path].tracef], tinf);
    if (nod[path].strand == -1 && nod[path].type != STOP)  nod[path].sscore             += intergenic_mod(&nod[path], &nod[nod[path].tracef], tinf);
    path = nod[path].tracef;
  }

  path = dbeg;

  while (nod[path].traceb != -1)
    path = nod[path].traceb;

  while (nod[path].tracef != -1) {
    if (nod[path].strand == 1 && nod[path].type != STOP && nod[path].cscore + nod[path].sscore < 0) {
      nod[path].elim = 1;
      nod[nod[path].tracef].elim = 1;
    }
    if (nod[path].strand == -1 && nod[path].type == STOP && nod[nod[path].tracef].cscore + nod[nod[path].tracef].sscore < 0) {
      nod[path].elim = 1;
      nod[nod[path].tracef].elim = 1;
    }
    path = nod[path].tracef;
  }

}






int count_genes(class _node *nod, int dbeg) {

  // This is a stripped down version of add_genes to count the number of genes
  // This code is not found in the original C version, which allocates memory for MAX_GENES genes. 

  int path,
      ctr;

  path = dbeg;
  ctr  = 0;

  while (nod[path].traceb != -1)
    path = nod[path].traceb;

  while(path != -1) { 

    if (nod[path].elim == 1) {
      path = nod[path].tracef;
      continue;
    }

    if(nod[path].strand ==  1 && nod[path].type == STOP) ctr++;
    if(nod[path].strand == -1 && nod[path].type != STOP) ctr++;

    path = nod[path].tracef;
  }

  return ctr;
}






int add_genes(class _gene *glist, class _node *nod, int dbeg) {

  int path,
      ctr;

  path = dbeg;
  ctr  = 0;

  while(nod[path].traceb != -1)
    path = nod[path].traceb;

  while(path != -1) { 

    if(nod[path].elim == 1) {
      path = nod[path].tracef;
      continue;
    }

    if(nod[path].strand == 1 && nod[path].type != STOP) {
      glist[ctr].begin = nod[path].ndx+1;
      glist[ctr].start_ndx = path;
    }

    if(nod[path].strand == -1 && nod[path].type == STOP) {
      glist[ctr].begin = nod[path].ndx-1;
      glist[ctr].stop_ndx = path;
    }

    if(nod[path].strand == 1 && nod[path].type == STOP) {
      glist[ctr].end = nod[path].ndx+3;
      glist[ctr].stop_ndx = path;
      ctr++;
    }

    if(nod[path].strand == -1 && nod[path].type != STOP) {
      glist[ctr].end = nod[path].ndx+1;
      glist[ctr].start_ndx = path;
      ctr++;
    }

    path = nod[path].tracef;
  }

  return ctr;
}






void tweak_final_starts(class _gene *genes, int ng, class _node *nod, int nn, class _training *tinf) {

  int i,
      j,
      ndx,
      mndx,
      maxndx[2];

  double sc,
         igm,
         tigm,
         maxsc[2],
         maxigm[2];

  for (i = 0; i < ng; i++) {
    ndx = genes[i].start_ndx;
    sc = nod[ndx].sscore + nod[ndx].cscore;
    igm = 0.0;
    if (i > 0 && nod[ndx].strand == 1 && nod[genes[i-1].start_ndx].strand ==  1) igm = intergenic_mod(&nod[genes[i-1].stop_ndx],  &nod[ndx], tinf);
    if (i > 0 && nod[ndx].strand == 1 && nod[genes[i-1].start_ndx].strand == -1) igm = intergenic_mod(&nod[genes[i-1].start_ndx], &nod[ndx], tinf);
    if (i < ng-1 && nod[ndx].strand == -1 && nod[genes[i+1].start_ndx].strand ==  1) igm = intergenic_mod(&nod[ndx], &nod[genes[i+1].start_ndx], tinf);
    if (i < ng-1 && nod[ndx].strand == -1 && nod[genes[i+1].start_ndx].strand == -1) igm = intergenic_mod(&nod[ndx], &nod[genes[i+1].stop_ndx],  tinf);

    // Search upstream and downstream for the #2 and #3 scoring starts

    maxndx[0] = -1;
    maxndx[1] = -1;
    maxsc[0]  =  0;
    maxsc[1]  =  0;
    maxigm[0] =  0;
    maxigm[1] =  0;

    for (j = ndx-100; j < ndx+100; j++) {
      if (j < 0 || j >= nn || j == ndx) continue;
      if (nod[j].type == STOP || nod[j].stop_val != nod[ndx].stop_val) continue;

      tigm = 0.0;

      if (i > 0 && nod[j].strand == 1 && nod[genes[i-1].start_ndx].strand == 1) {
        if (nod[genes[i-1].stop_ndx].ndx - nod[j].ndx > MAX_SAM_OVLP) continue;
        tigm = intergenic_mod(&nod[genes[i-1].stop_ndx], &nod[j], tinf);
      }

      if (i > 0 && nod[j].strand == 1 && nod[genes[i-1].start_ndx].strand == -1) {
        if (nod[genes[i-1].start_ndx].ndx - nod[j].ndx >= 0) continue;
        tigm = intergenic_mod(&nod[genes[i-1].start_ndx], &nod[j], tinf);
      }

      if (i < ng-1 && nod[j].strand == -1 && nod[genes[i+1].start_ndx].strand == 1) {
        if (nod[j].ndx - nod[genes[i+1].start_ndx].ndx >= 0) continue;
        tigm = intergenic_mod(&nod[j], &nod[genes[i+1].start_ndx], tinf);
      }

      if (i < ng-1 && nod[j].strand == -1 && nod[genes[i+1].start_ndx].strand == -1) {
        if (nod[j].ndx - nod[genes[i+1].stop_ndx].ndx > MAX_SAM_OVLP) continue;
        tigm = intergenic_mod(&nod[j], &nod[genes[i+1].stop_ndx], tinf);
      }

      if (maxndx[0] == -1) {
        maxndx[0] = j;
        maxsc[0]  = nod[j].cscore + nod[j].sscore;
        maxigm[0] = tigm;
      }
      else if (nod[j].cscore + nod[j].sscore + tigm > maxsc[0]) {
        maxndx[1] = maxndx[0];
        maxsc[1]  = maxsc[0];
        maxigm[1] = maxigm[0];
        maxndx[0] = j;
        maxsc[0]  = nod[j].cscore + nod[j].sscore;
        maxigm[0] = tigm;
      }
      else if (maxndx[1] == -1 || nod[j].cscore + nod[j].sscore + tigm > maxsc[1]) {
        maxndx[1] = j;
        maxsc[1]  = nod[j].cscore + nod[j].sscore;
        maxigm[1] = tigm;
      }
    }

    // Change the start if it is a TTG with better coding/RBS/upstream score
    // Also change the start if it is <=15bp but has better coding/RBS

    for (j = 0; j < 2; j++) {
      mndx = maxndx[j];
      if(mndx == -1) continue;

      // Start of less common type but with better coding, rbs, and upstream.
      // Must be 18 or more bases away from original.

      if (nod[mndx].tscore < nod[ndx].tscore && maxsc[j]-nod[mndx].tscore >= sc-nod[ndx].tscore+tinf->st_wt && nod[mndx].rscore > nod[ndx].rscore
         && nod[mndx].uscore > nod[ndx].uscore && nod[mndx].cscore > nod[ndx].cscore && abs(nod[mndx].ndx-nod[ndx].ndx) > 15) {
        maxsc[j] += nod[ndx].tscore-nod[mndx].tscore;
      }

      // Close starts. Ignore coding and see if start has better rbs and type.

      else if (abs(nod[mndx].ndx-nod[ndx].ndx) <= 15 && nod[mndx].rscore+ nod[mndx].tscore > nod[ndx].rscore+nod[ndx].tscore &&
              nod[ndx].edge == 0 && nod[mndx].edge == 0) {
        if (nod[ndx].cscore > nod[mndx].cscore) maxsc[j] += nod[ndx].cscore - nod[mndx].cscore;
        if (nod[ndx].uscore > nod[mndx].uscore) maxsc[j] += nod[ndx].uscore - nod[mndx].uscore;
        if (igm > maxigm[j]) maxsc[j] += igm - maxigm[j];
      }

      else maxsc[j] = -1000.0;
    }

    // Change the gene coordinates to the new maximum.

    mndx = -1;
    for (j = 0; j < 2; j++) {
      if (maxndx[j] == -1) continue;
      if (mndx == -1 && maxsc[j]+maxigm[j] > sc+igm)
        mndx = j;
      else if (mndx >= 0 && maxsc[j]+maxigm[j] > maxsc[mndx]+maxigm[mndx])
        mndx = j;
    }
    if (mndx != -1 && nod[maxndx[mndx]].strand == 1) {
      genes[i].start_ndx = maxndx[mndx];
      genes[i].begin = nod[maxndx[mndx]].ndx+1;
    }
    else if (mndx != -1 && nod[maxndx[mndx]].strand == -1) {
      genes[i].start_ndx = maxndx[mndx];
      genes[i].end = nod[maxndx[mndx]].ndx+1;
    }
  }
}







void mer_text(char *qt, int len, int ndx) {
  // Gives a text string for a mer of size len (useful for outputting motifs)

  int i;

  int pow = 1,
      quo = 0;

  if (len == 0) strcpy(qt, "None");
  else {

    for (i = 0; i < len-1; i++)
      pow *= 4;

    for (i = len-1; i > -1; i--) {
      quo = ndx / pow;
      if (quo == 0 ) strncpy(&qt[i], "A", 1);
      if (quo == 1 ) strncpy(&qt[i], "G", 1);
      if (quo == 2 ) strncpy(&qt[i], "C", 1);
      if (quo == 3 ) strncpy(&qt[i], "T", 1);
      ndx -= quo * pow;
      pow /= 4;
    }
  }
}






double calculate_confidence(double score, double start_weight) {
// Convert score to a percent confidence
  double conf;

  if (score/start_weight < 41) {
    conf = exp(score/start_weight);
    conf = (conf/(conf+1)) *100.0;
  }
  else conf = 99.99;
  if (conf <= 50.00) { conf = 50.00; }
  return conf;
}


//void amino(char *ggg, char *aaa) {

//}





int record_gene_data(class _gene *genes, int ng, class _node *nod, class _training *tinf, char *seq, int sctr) {

  // sctr is sequence counter

  #include <stdio.h>
  #include <string.h>

  int i,
      ndx,
      sndx,
      partial_left,
      partial_right,
      st_type;

  double rbs1, rbs2;

  char sd_string[28][15],      // length was 100 in original C code
       sd_spacer[28][8] ,      // length was  20 in original C code
       qt[10];

  char type_string[4][5] = { "ATG", "GTG", "TTG" , "Edge" };


  char gene_id[10],
       nonSD_spacer[5],
       partial[2];

  int  str_len;


  // Initialize RBS string information for default SD

  // Character arrays are dimensioned just large enough to hold the longest of the strings below,
  // including the terminating null character. strcpy adds the null character.

  strcpy(sd_string[0],  "None");
  strcpy(sd_spacer[0],  "None");
  strcpy(sd_string[1],  "GGA/GAG/AGG");
  strcpy(sd_spacer[1],  "3-4bp");
  strcpy(sd_string[2],  "3Base/5BMM");
  strcpy(sd_spacer[2],  "13-15bp");
  strcpy(sd_string[3],  "4Base/6BMM");
  strcpy(sd_spacer[3],  "13-15bp");
  strcpy(sd_string[4],  "AGxAG");
  strcpy(sd_spacer[4],  "11-12bp");
  strcpy(sd_string[5],  "AGxAG");
  strcpy(sd_spacer[5],  "3-4bp");
  strcpy(sd_string[6],  "GGA/GAG/AGG");
  strcpy(sd_spacer[6],  "11-12bp");
  strcpy(sd_string[7],  "GGxGG");
  strcpy(sd_spacer[7],  "11-12bp");
  strcpy(sd_string[8],  "GGxGG");
  strcpy(sd_spacer[8],  "3-4bp");
  strcpy(sd_string[9],  "AGxAG");
  strcpy(sd_spacer[9],  "5-10bp");
  strcpy(sd_string[10], "AGGAG(G)/GGAGG");
  strcpy(sd_spacer[10], "13-15bp");
  strcpy(sd_string[11], "AGGA/GGAG/GAGG");
  strcpy(sd_spacer[11], "3-4bp");
  strcpy(sd_string[12], "AGGA/GGAG/GAGG");
  strcpy(sd_spacer[12], "11-12bp");
  strcpy(sd_string[13], "GGA/GAG/AGG");
  strcpy(sd_spacer[13], "5-10bp");
  strcpy(sd_string[14], "GGxGG");
  strcpy(sd_spacer[14], "5-10bp");
  strcpy(sd_string[15], "AGGA");
  strcpy(sd_spacer[15], "5-10bp");
  strcpy(sd_string[16], "GGAG/GAGG");
  strcpy(sd_spacer[16], "5-10bp");
  strcpy(sd_string[17], "AGxAGG/AGGxGG");
  strcpy(sd_spacer[17], "11-12bp");
  strcpy(sd_string[18], "AGxAGG/AGGxGG");
  strcpy(sd_spacer[18], "3-4bp");
  strcpy(sd_string[19], "AGxAGG/AGGxGG");
  strcpy(sd_spacer[19], "5-10bp");
  strcpy(sd_string[20], "AGGAG/GGAGG");
  strcpy(sd_spacer[20], "11-12bp");
  strcpy(sd_string[21], "AGGAG");
  strcpy(sd_spacer[21], "3-4bp");
  strcpy(sd_string[22], "AGGAG");
  strcpy(sd_spacer[22], "5-10bp");
  strcpy(sd_string[23], "GGAGG");
  strcpy(sd_spacer[23], "3-4bp");
  strcpy(sd_string[24], "GGAGG");
  strcpy(sd_spacer[24], "5-10bp");
  strcpy(sd_string[25], "AGGAGG");
  strcpy(sd_spacer[25], "11-12bp");
  strcpy(sd_string[26], "AGGAGG");
  strcpy(sd_spacer[26], "3-4bp");
  strcpy(sd_string[27], "AGGAGG");
  strcpy(sd_spacer[27], "5-10bp");



  int gene_len,
      max_gene_len = 0;


  for(i = 0; i < ng; i++) {

    str_len = sprintf(gene_id, "%d_%d", sctr, i+1);
    strcpy(genes[i].identifier, gene_id);
    
    ndx =  genes[i].start_ndx;
    sndx = genes[i].stop_ndx;

    genes[i].strand = nod[ndx].strand;

    // Record basic gene data

    if((nod[ndx].edge == 1 && nod[ndx].strand == 1) ||
       (nod[sndx].edge == 1 && nod[ndx].strand == -1))
      partial_left = 1;
    else partial_left = 0;
    if((nod[sndx].edge == 1 && nod[ndx].strand == 1) ||
       (nod[ndx].edge == 1 && nod[ndx].strand == -1))
      partial_right = 1;
    else partial_right = 0;
    if(nod[ndx].edge == 1) st_type = 3;
    else st_type = nod[ndx].type;

    str_len = sprintf(partial, "%d%d", partial_left, partial_right);
    strcpy(genes[i].partial, partial);

    strcpy(genes[i].start_type, type_string[st_type]);
   


    // Record rbs data

    rbs1 = tinf->rbs_wt[nod[ndx].rbs[0]]*tinf->st_wt;
    rbs2 = tinf->rbs_wt[nod[ndx].rbs[1]]*tinf->st_wt;

    if(tinf->uses_sd == 1) {
      if(rbs1 > rbs2) {
        strcpy(genes[i].rbs_motif,  sd_string[nod[ndx].rbs[0]]);
        strcpy(genes[i].rbs_spacer, sd_spacer[nod[ndx].rbs[0]]);
      }
      else {
        strcpy(genes[i].rbs_motif,  sd_string[nod[ndx].rbs[1]]);
        strcpy(genes[i].rbs_spacer, sd_spacer[nod[ndx].rbs[1]]);
      }
    }

    else {
      if (tinf->no_mot > -0.5 && rbs1 > rbs2 && rbs1 > nod[ndx].mot.score * tinf->st_wt) {
        strcpy(genes[i].rbs_motif,  sd_string[nod[ndx].rbs[0]]);
        strcpy(genes[i].rbs_spacer, sd_spacer[nod[ndx].rbs[0]]);
      }
      else if (tinf->no_mot > -0.5 && rbs2 >= rbs1 && rbs2 > nod[ndx].mot.score * tinf->st_wt) {
        strcpy(genes[i].rbs_motif,  sd_string[nod[ndx].rbs[1]]);
        strcpy(genes[i].rbs_spacer, sd_spacer[nod[ndx].rbs[1]]);
      }
      else if(nod[ndx].mot.len == 0) {
        strcpy(genes[i].rbs_motif,  sd_string[0]);
        strcpy(genes[i].rbs_spacer, sd_spacer[0]);
      }
      else {
        mer_text(qt, nod[ndx].mot.len, nod[ndx].mot.ndx);
        strcpy(genes[i].rbs_motif, qt);
        str_len = sprintf(nonSD_spacer, "%dbp", nod[ndx].mot.spacer);
        strcpy(genes[i].rbs_spacer, nonSD_spacer);
      }
    }

    genes[i].gc_cont = nod[ndx].gc_cont;

    // Record score data

    genes[i].confidence = calculate_confidence(nod[ndx].cscore + nod[ndx].sscore, tinf->st_wt);
    genes[i].score      = nod[ndx].cscore + nod[ndx].sscore;
    genes[i].cscore     = nod[ndx].cscore;
    genes[i].sscore     = nod[ndx].sscore;
    genes[i].rscore     = nod[ndx].rscore;
    genes[i].uscore     = nod[ndx].uscore;
    genes[i].tscore     = nod[ndx].tscore;

    // Determine length of longest gene sequence
    
    gene_len = genes[i].end - genes[i].begin + 1;
    if (gene_len > max_gene_len) {
      max_gene_len = gene_len;
    }
  }

  return(max_gene_len);
}







// [[Rcpp::export]]

List do_training(DataFrame NDF, List TL, CharacterVector sequence, CharacterVector reverse) {

  using namespace std;

  // Convert the sequences

  std::string sss;
  sss.assign(sequence[0]);
  char *seq = &sss[0];

  std::string rrr;
  rrr.assign(reverse[0]);
  char *rev = &rrr[0];

  int slen = sss.length();



  // Node DataFrame

  Rcpp::CharacterVector type            = NDF["type"          ];
  Rcpp::LogicalVector   edge            = NDF["edge"          ];
  Rcpp::IntegerVector   ndx             = NDF["ndx"           ];
  Rcpp::CharacterVector strand          = NDF["strand"        ];
  Rcpp::IntegerVector   stop_val        = NDF["stop_val"      ];
  Rcpp::IntegerVector   star_ptr_1      = NDF["star_ptr_1"    ];
  Rcpp::IntegerVector   star_ptr_2      = NDF["star_ptr_2"    ];
  Rcpp::IntegerVector   star_ptr_3      = NDF["star_ptr_3"    ];
  Rcpp::IntegerVector   gc_bias         = NDF["gc_bias"       ];
  Rcpp::NumericVector   gc_score_1      = NDF["gc_score_1"    ];
  Rcpp::NumericVector   gc_score_2      = NDF["gc_score_2"    ];
  Rcpp::NumericVector   gc_score_3      = NDF["gc_score_3"    ];
  Rcpp::NumericVector   cscore          = NDF["cscore"        ];
  Rcpp::NumericVector   gc_cont         = NDF["gc_cont"       ];
  Rcpp::IntegerVector   rbs_1           = NDF["rbs_1"         ];
  Rcpp::IntegerVector   rbs_2           = NDF["rbs_2"         ];
  Rcpp::IntegerVector   motif_ndx       = NDF["motif_ndx"     ];
  Rcpp::IntegerVector   motif_len       = NDF["motif_len"     ];
  Rcpp::IntegerVector   motif_spacer    = NDF["motif_spacer"  ];
  Rcpp::IntegerVector   motif_spacendx  = NDF["motif_spacendx"];
  Rcpp::NumericVector   motif_score     = NDF["motif_score"   ];
  Rcpp::NumericVector   uscore          = NDF["uscore"        ];
  Rcpp::NumericVector   tscore          = NDF["tscore"        ];
  Rcpp::NumericVector   rscore          = NDF["rscore"        ];
  Rcpp::NumericVector   sscore          = NDF["sscore"        ];
  Rcpp::IntegerVector   traceb          = NDF["traceb"        ];
  Rcpp::IntegerVector   tracef          = NDF["tracef"        ];
  Rcpp::IntegerVector   ov_mark         = NDF["ov_mark"       ];
  Rcpp::NumericVector   node_score      = NDF["score"         ];    // Vector name modified to avoid conflict with a local variable
  Rcpp::LogicalVector   elim            = NDF["elim"          ];

  int nn = type.length();

  _node *nodes = new _node[nn];

  int i;

  // Copy data from DataFrame to Node and Motif Classes

  for (i = 0; i < nn; i++) {
    if (type[i] == "ATG" ) nodes[i].type = 0;
    if (type[i] == "GTG" ) nodes[i].type = 1;
    if (type[i] == "TTG" ) nodes[i].type = 2;
    if (type[i] == "STOP") nodes[i].type = 3;


    if (edge[i] == TRUE ) nodes[i].edge = 1;
    if (edge[i] == FALSE) nodes[i].edge = 0;

    nodes[i].ndx = ndx[i];

    if (strand[i] == "+" ) nodes[i].strand =  1;
    if (strand[i] == "-" ) nodes[i].strand = -1;

    nodes[i].stop_val = stop_val[i];

    nodes[i].star_ptr[0] = star_ptr_1[i];
    nodes[i].star_ptr[1] = star_ptr_2[i];
    nodes[i].star_ptr[2] = star_ptr_3[i];

    nodes[i].gc_bias = gc_bias[i];

    nodes[i].gc_score[0] = gc_score_1[i];
    nodes[i].gc_score[1] = gc_score_2[i];
    nodes[i].gc_score[2] = gc_score_3[i];

    nodes[i].cscore = cscore[i];

    nodes[i].gc_cont = gc_cont[i];

    nodes[i].rbs[0] = rbs_1[i];
    nodes[i].rbs[1] = rbs_2[i];

    nodes[i].mot.ndx      = motif_ndx[i];
    nodes[i].mot.len      = motif_len[i];
    nodes[i].mot.spacer   = motif_spacer[i];
    nodes[i].mot.spacendx = motif_spacendx[i];
    nodes[i].mot.score    = motif_score[i];

    nodes[i].uscore = uscore[i];
    nodes[i].tscore = tscore[i];
    nodes[i].rscore = rscore[i];
    nodes[i].sscore = sscore[i];

    nodes[i].traceb = traceb[i];
    nodes[i].tracef = tracef[i];

    nodes[i].ov_mark = ov_mark[i];

    nodes[i].score = node_score[i];

    if (elim[i] == TRUE ) nodes[i].elim = 1;
    if (elim[i] == FALSE) nodes[i].elim = 0;
  }


  // Training List

  _training *train = new _training;

  // Assign scalars
  train->gc          = as<double>(TL["gc"         ]);
  train->trans_table = as<int>   (TL["trans_table"]);
  train->st_wt       = as<double>(TL["st_wt"      ]);
  train->uses_sd     = as<int>   (TL["uses_sd"    ]);
  train->no_mot      = as<double>(TL["no_mot"     ]);

  // Assign vectors
  Rcpp::NumericVector train_bias     = TL["bias"    ];
  Rcpp::NumericVector train_type_wt  = TL["type_wt" ];
  Rcpp::NumericVector train_rbs_wt   = TL["rbs_wt"  ];
  Rcpp::NumericMatrix train_ups_comp = TL["ups_comp"];  // NumericMatrix transposes the 2-D array from the R list from column-major to row-major
  Rcpp::NumericVector train_mot_wt   = TL["mot_wt"  ];
  Rcpp::NumericVector train_gene_dc  = TL["gene_dc" ];

  int a, b, c, d, j;  // additional array indices

  for (i = 0; i < 3; i++) {
    train->bias[i]    = train_bias[i];
    train->type_wt[i] = train_type_wt[i];
  }

  for (i = 0; i < 28; i++)
    train->rbs_wt[i] = train_rbs_wt[i];

  // double ups_comp[32][4];

  for (i = 0; i < 32; i++)
    for (j = 0; j < 4; j++ )
      train->ups_comp[i][j] = train_ups_comp(i,j);     // Note the lack of transposition ... and the different subscripting syntax

  // mot_wt is a 3-D array in the C implementation and a 3-D array in the R list that defines the training structure.
  // However, it cannot easily be passed as such into an Rcpp function, because there is not an Rcpp 3-D datatype.
  // The situation is further complicated since R is a 1-indexed, column-major language, and C is a 0-indexed,
  // row-major language. The implemented solution is to a pass a 3-D R matix into a 1-D Rcpp array and
  // then unpack it into a new transposed 3-D C++ array for use inside this function. Unfortunately, once unpacked,
  // it is hard to put it back in the box.
  // dim(vec) <- c(7, 7)

  // Note: data type for mot_wt is double mot_wt[4][4][4096]

  d = 0;
  for (a = 0; a < 4096; a++)
    for (b = 0; b < 4; b++)
      for (c = 0; c < 4; c++)
        train->mot_wt[c][b][a] = train_mot_wt[d++];  // Note the transposition

  // train->mot_wt[2][1][6] = 1492.10;     // TEST -- Columbus rediscovers America

  for (i = 0; i < 4096; i++)
    train->gene_dc[i] = train_gene_dc[i];




  // *************************************
  // * Call to RECORD_OVERLAPPING_STARTS *
  // *************************************

  Rcout << "Building initial set of genes to train from ...";

  record_overlapping_starts(nodes, nn, train, 0);



  // *****************
  // * Call to DPROG *
  // *****************

  // Basic dynamic programming routine for predicting genes. The flag variable is set to 0 for the initial
  // dynamic programming routine based solely on GC frame plot -- used to construct a training set. If the
  // flag is set to 1, the routine does the final dynamic programming based on coding, RBS scores, etc.

  int ipath;

  ipath = dprog(nodes, nn, train, 0);

  Rcout << " done!" << std::endl;



  // *****************************
  // * Call to CALC_DICODON_GENE *
  // *****************************

  // Simple routine that calculates the dicodon frequency in genes and in the background,
  // and then stores the log likelihood of each 6-mer relative to the background.

  Rcout << "Creating coding model and scoring nodes ...";

  calc_dicodon_gene(train, seq, rev, slen, nodes, ipath);

  if (0) {
    for (i = 0; i < nn; i++) {
      Rcout << "ndx: " << nodes[i].ndx << ", cscore: " << nodes[i].cscore << std::endl;
    }
  }

  if (0) {
    for (i = 0; i < 4096; i++) {
      Rcout << i << ": " << train->gene_dc[i] << std::endl;
    }
  }


  // ****************************
  // * Call to RAW_CODING_SCORE *
  // ****************************

  // Score coding of each candidate.  We also sharpen coding/noncoding thresholds to prevent
  // choosing interior starts when there is strong coding continuing upstream.

  // Debug statement
  if (0) {
    Rcout << "Calling raw_coding_score from main" << std::endl;
  }
  raw_coding_score(seq, rev, slen, nodes, nn, train);

  // Debug statement
  if (0) {
    for (i = 0; i < nn; i++) {
      Rcout << "ndx: " << nodes[i].ndx << ", cscore: " << nodes[i].cscore << std::endl;
    }
  }

  Rcout << " done!" << std::endl;


  // Determine if this organism uses Shine-Dalgarno or not and score the nodes appropriately.

  // *********************
  // * Call to RBS_SCORE *
  // *********************

  // Calculate the RBS motif and then multiply it by the appropriate weight for that motif,
  // which is determined in the start training function.

  Rcout << "Examining upstream regions and training starts ...";

  rbs_score(seq, rev, slen, nodes, nn, train);



  // **************************************************
  // * Call to TRAIN_STARTS_SD and DETERMINE_SD_USAGE *
  // **************************************************

  // Iterative Algorithm to train starts.  It begins with all the highest coding starts in the model,
  // scans for RBS/ATG-GTG-TTG usage, then starts moving starts around attempting to match these discoveries.
  // This start trainer is for Shine-Dalgarno motifs only.

  train_starts_sd(seq, rev, slen, nodes, nn, train);

  // Debug statement
  if (0) {
    for (i = 0; i < nn; i++) {
      Rcout << "ndx: " << nodes[i].ndx << ", cscore: " << nodes[i].cscore << std::endl;
    }
  }


  // Examines the results of the SD motif search to determine if this organism uses an SD motif or not.
  // Some motif of 3-6bp has to be good or we set uses_sd to 0, which will cause Prodigal
  // to run the non-SD motif finder for starts.

  determine_sd_usage(train);

  // ******************************************
  // * Conditional call to TRAIN_STARTS_NONSD *
  // ******************************************

  // train->uses_sd = 0;  // Test to force execution of train_starts_nonsd

  // Iterative Algorithm to train starts.  It begins with all the highest coding starts in the model,
  // scans for RBS/ATG-GTG-TTG usage, then starts moving starts around attempting to match these discoveries.
  // Unlike the SD algorithm, it allows for any popular motif to be discovered.

  if (train->uses_sd == 0) {
    train_starts_nonsd(seq, rev, slen, nodes, nn, train);
  }

  Rcout << " done!" << std::endl;

  // Debug statement
  if (0) {
    for (i = 0; i < nn; i++) {
      Rcout << "ndx: " << nodes[i].ndx << ", cscore: " << nodes[i].cscore << std::endl;
    }
  }




  // ********************************************
  // * Return the TRAINING data ...             *
  // *   Put the training data back into a List *
  // ********************************************

  // ******* double gc ... GC content
  TL["gc"] = train->gc;


  // ******* int trans_table ... Translation table
  TL["trans_table"] = train->trans_table;


  // ******* double st_wt ... Start weight
  TL["st_wt"] = train->st_wt;


  // ******* double bias[3] ... GC frame bias for each of the 3 positions
  NumericVector nv_bias(3);
  for (i = 0; i < 3; i++) {
    nv_bias[i] = train->bias[i];
  }
  TL["bias"] = nv_bias;


  // ******* double type_wt[3] ... Weights for ATG vs GTG vs TTG
  NumericVector nv_type_wt(3);
  for (i = 0; i < 3; i++) {
    nv_type_wt[i] = train->type_wt[i];
  }
  TL["type_wt"] = nv_type_wt;


  // ******* double type_wt[3] ... Weights for ATG vs GTG vs TTG
  TL["uses_sd"] = train->uses_sd;


  // ******* double rbs_wt[28] ... Set of weights for RBS scores
  NumericVector nv_rbs_wt(28);
  for (i = 0; i < 28; i++) {
    nv_rbs_wt[i] = train->rbs_wt[i];
  }
  TL["rbs_wt"] = nv_rbs_wt;


  // ******* double ups_comp[32][4] ... Base composition weights for non-RBS-distance motifs
  NumericMatrix nm_ups_comp(4,32);
  for (i = 0; i < 32; i++)
    for (j = 0; j < 4; j++)
      nm_ups_comp(j,i) = train->ups_comp[i][j];     // Note the transposition ... NumericMatrix is NOT transposed upon return to the R world
  TL["ups_comp"] = nm_ups_comp;


  // ******* double mot_wt[4][4][4096] ... Weights for upstream motifs
  NumericVector nv_mot_wt(65536);
  d = 0;
  for (a = 0; a < 4096; a++)
    for (b = 0; b < 4; b++)
      for (c = 0; c < 4; c++)
        nv_mot_wt[d++] = train->mot_wt[c][b][a];     // Note the transposition ... will be redimensioned as 3D when back in the R world
  TL["mot_wt"] = nv_mot_wt;


  // ******* double no_mot ... Weight for the case of no motif
  TL["no_mot"] = train->no_mot;


  // ******* double gene_dc[4096] ... Coding statistics for the genome
  NumericVector nv_gene_dc(4096);
  for (i = 0; i < 4096; i++) {
    nv_gene_dc[i] = train->gene_dc[i];
  }
  TL["gene_dc"] = nv_gene_dc;


  return(TL);

}





// [[Rcpp::export]]

DataFrame find_genes(DataFrame NDF, List TL, CharacterVector sequence, CharacterVector reverse) {

  using namespace std;

  // Convert the sequences

  std::string sss;
  sss.assign(sequence[0]);
  char *seq = &sss[0];

  std::string rrr;
  rrr.assign(reverse[0]);
  char *rev = &rrr[0];

  int slen = sss.length();



  // Node DataFrame

  Rcpp::CharacterVector type            = NDF["type"          ];
  Rcpp::LogicalVector   edge            = NDF["edge"          ];
  Rcpp::IntegerVector   ndx             = NDF["ndx"           ];
  Rcpp::CharacterVector strand          = NDF["strand"        ];
  Rcpp::IntegerVector   stop_val        = NDF["stop_val"      ];
  Rcpp::IntegerVector   star_ptr_1      = NDF["star_ptr_1"    ];
  Rcpp::IntegerVector   star_ptr_2      = NDF["star_ptr_2"    ];
  Rcpp::IntegerVector   star_ptr_3      = NDF["star_ptr_3"    ];
  Rcpp::IntegerVector   gc_bias         = NDF["gc_bias"       ];
  Rcpp::NumericVector   gc_score_1      = NDF["gc_score_1"    ];
  Rcpp::NumericVector   gc_score_2      = NDF["gc_score_2"    ];
  Rcpp::NumericVector   gc_score_3      = NDF["gc_score_3"    ];
  Rcpp::NumericVector   cscore          = NDF["cscore"        ];
  Rcpp::NumericVector   gc_cont         = NDF["gc_cont"       ];
  Rcpp::IntegerVector   rbs_1           = NDF["rbs_1"         ];
  Rcpp::IntegerVector   rbs_2           = NDF["rbs_2"         ];
  Rcpp::IntegerVector   motif_ndx       = NDF["motif_ndx"     ];
  Rcpp::IntegerVector   motif_len       = NDF["motif_len"     ];
  Rcpp::IntegerVector   motif_spacer    = NDF["motif_spacer"  ];
  Rcpp::IntegerVector   motif_spacendx  = NDF["motif_spacendx"];
  Rcpp::NumericVector   motif_score     = NDF["motif_score"   ];
  Rcpp::NumericVector   uscore          = NDF["uscore"        ];
  Rcpp::NumericVector   tscore          = NDF["tscore"        ];
  Rcpp::NumericVector   rscore          = NDF["rscore"        ];
  Rcpp::NumericVector   sscore          = NDF["sscore"        ];
  Rcpp::IntegerVector   traceb          = NDF["traceb"        ];
  Rcpp::IntegerVector   tracef          = NDF["tracef"        ];
  Rcpp::IntegerVector   ov_mark         = NDF["ov_mark"       ];
  Rcpp::NumericVector   node_score      = NDF["score"         ];    // Vector name modified to avoid conflict with a local variable
  Rcpp::LogicalVector   elim            = NDF["elim"          ];

  int nn = type.length();

  _node *nodes = new _node[nn];

  int i;

  // Copy data from DataFrame to Node and Motif Classes

  for (i = 0; i < nn; i++) {
    if (type[i] == "ATG" ) nodes[i].type = 0;
    if (type[i] == "GTG" ) nodes[i].type = 1;
    if (type[i] == "TTG" ) nodes[i].type = 2;
    if (type[i] == "STOP") nodes[i].type = 3;


    if (edge[i] == TRUE ) nodes[i].edge = 1;
    if (edge[i] == FALSE) nodes[i].edge = 0;

    nodes[i].ndx = ndx[i];

    if (strand[i] == "+" ) nodes[i].strand =  1;
    if (strand[i] == "-" ) nodes[i].strand = -1;

    nodes[i].stop_val = stop_val[i];

    nodes[i].star_ptr[0] = star_ptr_1[i];
    nodes[i].star_ptr[1] = star_ptr_2[i];
    nodes[i].star_ptr[2] = star_ptr_3[i];

    nodes[i].gc_bias = gc_bias[i];

    nodes[i].gc_score[0] = gc_score_1[i];
    nodes[i].gc_score[1] = gc_score_2[i];
    nodes[i].gc_score[2] = gc_score_3[i];

    nodes[i].cscore = cscore[i];

    nodes[i].gc_cont = gc_cont[i];

    nodes[i].rbs[0] = rbs_1[i];
    nodes[i].rbs[1] = rbs_2[i];

    nodes[i].mot.ndx      = motif_ndx[i];
    nodes[i].mot.len      = motif_len[i];
    nodes[i].mot.spacer   = motif_spacer[i];
    nodes[i].mot.spacendx = motif_spacendx[i];
    nodes[i].mot.score    = motif_score[i];

    nodes[i].uscore = uscore[i];
    nodes[i].tscore = tscore[i];
    nodes[i].rscore = rscore[i];
    nodes[i].sscore = sscore[i];

    nodes[i].traceb = traceb[i];
    nodes[i].tracef = tracef[i];

    nodes[i].ov_mark = ov_mark[i];

    nodes[i].score = node_score[i];

    if (elim[i] == TRUE ) nodes[i].elim = 1;
    if (elim[i] == FALSE) nodes[i].elim = 0;
  }


  // Training List

  _training *train = new _training;

  // Assign scalars
  train->gc          = as<double>(TL["gc"         ]);
  train->trans_table = as<int>   (TL["trans_table"]);
  train->st_wt       = as<double>(TL["st_wt"      ]);
  train->uses_sd     = as<int>   (TL["uses_sd"    ]);
  train->no_mot      = as<double>(TL["no_mot"     ]);

  // Assign vectors
  Rcpp::NumericVector train_bias     = TL["bias"    ];
  Rcpp::NumericVector train_type_wt  = TL["type_wt" ];
  Rcpp::NumericVector train_rbs_wt   = TL["rbs_wt"  ];
  Rcpp::NumericMatrix train_ups_comp = TL["ups_comp"];  // NumericMatrix transposes the 2-D array from the R list from column-major to row-major
  Rcpp::NumericVector train_mot_wt   = TL["mot_wt"  ];
  Rcpp::NumericVector train_gene_dc  = TL["gene_dc" ];

  int a, b, c, d, j;  // additional array indices

  for (i = 0; i < 3; i++) {
    train->bias[i]    = train_bias[i];
    train->type_wt[i] = train_type_wt[i];
  }

  for (i = 0; i < 28; i++)
    train->rbs_wt[i] = train_rbs_wt[i];

  // double ups_comp[32][4];

  for (i = 0; i < 32; i++)
    for (j = 0; j < 4; j++ )
      train->ups_comp[i][j] = train_ups_comp(j,i);     // Note the transposition ... and the different subscripting syntax


  // mot_wt is a 3-D array in the C implementation and a 3-D array in the R list that defines the training structure.
  // However, it cannot easily be passed as such into an Rcpp function, because there is not an Rcpp 3-D datatype.
  // The situation is further complicated since R is a 1-indexed, column-major language, and C is a 0-indexed,
  // row-major language. The implemented solution is to a pass a 3-D R matix into a 1-D Rcpp array and
  // then unpack it into a new transposed 3-D C++ array for use inside this function. Unfortunately, once unpacked,
  // it is hard to put it back in the box.
  // dim(vec) <- c(7, 7)

  // Note: data type for mot_wt is double mot_wt[4][4][4096]

  d = 0;
  for (a = 0; a < 4096; a++)
    for (b = 0; b < 4; b++)
      for (c = 0; c < 4; c++)
        train->mot_wt[c][b][a] = train_mot_wt[d++];  // Note the transposition

  // train->mot_wt[2][1][6] = 1492.10;     // TEST -- Columbus rediscovers America

  for (i = 0; i < 4096; i++)
    train->gene_dc[i] = train_gene_dc[i];








  // ***********************
  // * Call to SCORE_NODES *
  // ***********************

  // Scoring function for all the start nodes.  This score has two factors:
  // (1) Coding, which is a composite of coding score and length, and
  // (2) Start score, which is a composite of RBS score and ATG/TTG/GTG.

  // Note: The call to score_nodes in the original C version has two additional parameters:
  // * closed - a user flag for closed ends. Do not allow genes to run off edges.
  //      We assume closed = FALSE.
  // * is_meta - a flag that indicates whether a metagenome is detected, i.e., the input file contains multiple FASTA sequences.
  //      We assume is_meta = FALSE, i.e., in the initial R refactorization, we handle only the single chromosome case.

  score_nodes(seq, rev, slen, nodes, nn, train);


  // *************************************
  // * Call to RECORD_OVERLAPPING_STARTS *
  // *************************************


  record_overlapping_starts(nodes, nn, train, 1);


  // *****************
  // * Call to DPROG *
  // *****************

  // Basic dynamic programming routine for predicting genes. The flag variable is set to 0 for the initial
  // dynamic programming routine based solely on GC frame plot (used to construct a training set). If the
  // flag is set to 1, the routine does the final dynamic programming based on coding, RBS scores, etc.

  int ipath;

  ipath = dprog(nodes, nn, train, 1);


  // *******************************
  // * Call to ELIMINATE_BAD_GENES *
  // *******************************

  // Sometimes bad genes creep into the model due to the node distance constraint in the dynamic programming routine.
  // This routine just does a sweep through the genes and eliminates ones with negative scores.

  eliminate_bad_genes(nodes, ipath, train);


  // **************************************
  // * Calls to COUNT_GENES and ADD_GENES *
  // **************************************

  // This routine is a stripped down version of add_genes.
  // It makes a pass through the node structures to determine the number of genes, in order to dimension the genes variable.

  int ng = count_genes(nodes, ipath);


  // Copy genes from the dynamic programming to a final array

  _gene *genes = new _gene[ng];

  ng = add_genes(genes, nodes, ipath);


  // ******************************
  // * Call to TWEAK_FINAL STARTS *
  // ******************************

  // This routine attempts to solve the problem of extremely close starts.  If two potential starts are 5 amino acids or
  // less away from each other, this routine sets their coding equal to each other and lets the RBS/operon/ATG-GTG-TTG
  // start features determine which start to use, under the assumption that 5 or less words of coding is too weak a signal
  // to use to select the proper start.

  // In addition, we try to correct TTG (or whatever start codon is rare) starts that have an RBS score, an upstream score,
  // and a coding score all superior to whatever start we initially chose.

  // This routine was tested on numerous genomes and found to increase overall performance.

  tweak_final_starts(genes, ng, nodes, nn, train);




  // ****************************
  // * Call to RECORD_GENE_DATA *
  // ****************************

  int max_gene_len = record_gene_data(genes, ng, nodes, train, seq, 1);  // Returns length of longest gene nucleotide sequence

  // max_gen_len is never used - perhaps it was returned for a good reason? ... possible expansion of Prodigal functionality?
  // ... for now, let's zero it out to avoid a compiler warning.

  max_gene_len = 0;

  // Pitch the nodes - they've done their job

  delete[] nodes;

  // ********************************
  // * Call to RECORD_SEQUENCE_DATA *
  // ********************************

  // Currently implemented here, rather than in a separate function

  CharacterVector cv_g_sequence(ng);
  CharacterVector cv_p_sequence(ng);

  string genome_seq(seq);
  string gene_seq, protein, aa, codon;
  int    gene_len;

  for (i = 0; i < ng; i++) {
    gene_len = genes[i].end - genes[i].begin + 1;
    gene_seq = genome_seq.substr(genes[i].begin-1, gene_len);


    if (genes[i].strand == -1) {     // Reverse complement for sequences on the reverse strand
      std::reverse(gene_seq.begin(), gene_seq.end());
      replace(gene_seq.begin(), gene_seq.end(), 'A', 'X');
      replace(gene_seq.begin(), gene_seq.end(), 'T', 'A');
      replace(gene_seq.begin(), gene_seq.end(), 'X', 'T');
      replace(gene_seq.begin(), gene_seq.end(), 'C', 'X');
      replace(gene_seq.begin(), gene_seq.end(), 'G', 'C');
      replace(gene_seq.begin(), gene_seq.end(), 'X', 'G');
    }

    bool start = true;

    j = 0;
    while ((unsigned)j < gene_seq.length()) {
      codon = gene_seq.substr(j,3);
  
      aa = 'X';  // If an 'X' shows up in the protein sequence ...
                 //   ... we have a problem: a first codon that is not a start codon ...
                 //   ... or an error in the code below.
  
      // Base 1 is 'A'
      if (codon[0] == 'A') {
        if (codon[1] == 'T') {
          if (start)                { aa = 'M'; }
          else if (codon[2] == 'G') { aa = 'M'; }
          else                      { aa = 'I'; }
        }
        else if (codon[1] == 'C') { aa = 'T'; }
        else if (codon[1] == 'A') {
          if (codon[2] == 'T' || codon[2] == 'C') { aa = 'N'; }
          else                                    { aa = 'K'; }
        }
        else {  // codon[1] is G
          if (codon[2] == 'T' || codon[2] == 'C') { aa = 'S'; }
          else                                    { aa = 'R'; }
        }
      }
      // Base 1 is 'C'
      else if (codon[0] == 'C') {
        if (codon[1] == 'T') {
          if (start) { aa = 'M'; }
          else       { aa = 'L'; }
        }
        else if (codon[1] == 'C') { aa = 'P'; }
        else if (codon[1] == 'G') { aa = 'R'; }
        else {  // codon[1] is A
          if (codon[2] == 'T' || codon[2] == 'C') { aa = 'H'; }
          else                                    { aa = 'Q'; }
        }
      }
      // Base 1 is 'G'
      else if (codon[0] == 'G') {
        if (codon[1] == 'T') {
          if (codon[2] == 'G') {
            if (start) { aa = 'M'; }
            else       { aa = 'V'; }
          }
          else { aa = 'V'; }
        }
        else if (codon[1] == 'C') { aa = 'A'; }
        else if (codon[1] == 'G') { aa = 'G'; }
        else {  // codon[1] is A
          if (codon[2] == 'T' || codon[2] == 'C') { aa = 'D'; }
          else                                    { aa = 'E'; }
        }
      }
      // Base 1 is 'T'
      else {
        if (codon[1] == 'T') {
          if (codon[2] == 'G') {
            if (start) { aa = 'M'; }
            else       { aa = 'L'; }
          }
          else if (codon[2] == 'A') { aa = 'L'; }
          else                      { aa = 'F'; }
        }
        else if (codon[1] == 'C') { aa = 'S'; }
        else if (codon[1] == 'A') {
          if (codon[2] == 'T' || codon[2] == 'C') { aa = 'Y'; }
          else                                    { aa = '*'; }
        }
        else {  // codon[1] is G
          if (codon[2] == 'T' || codon[2] == 'C') { aa = 'C'; }
          else if (codon[2] == 'A')               { aa = '*'; }
          else                                    { aa = 'W'; }
        }
      }
  
      protein.append(aa);
  
      start = false;
      j += 3;
    }

    cv_g_sequence[i] = gene_seq;
    cv_p_sequence[i] = protein;

    protein.clear();
  }






  // *******************************************
  // *******************************************
  // Prepare data to return to the R environment
  // *******************************************
  // *******************************************


  // Put the GENE data into a DataFrame

  CharacterVector cv_identifier(ng);
  IntegerVector   iv_begin(ng);
  IntegerVector   iv_end(ng);
  CharacterVector cv_gstrand(ng);
  IntegerVector   iv_start_ndx(ng);
  IntegerVector   iv_stop_ndx(ng);
  CharacterVector cv_partial(ng);
  CharacterVector cv_start_type(ng);
  CharacterVector cv_rbs_motif(ng);
  CharacterVector cv_rbs_spacer(ng);
  NumericVector   nv_GCcont(ng);
  NumericVector   nv_confidence(ng);
  NumericVector   nv_g_score(ng);
  NumericVector   nv_g_cscore(ng);
  NumericVector   nv_g_sscore(ng);
  NumericVector   nv_g_rscore(ng);
  NumericVector   nv_g_uscore(ng);
  NumericVector   nv_g_tscore(ng);

//  CharacterVector cv_g_sequence(ng);



  for (i = 0; i < ng; i++) {
    cv_identifier[i]  = genes[i].identifier;
    iv_begin[i]       = genes[i].begin;
    iv_end[i]         = genes[i].end;
    if (genes[i].strand ==  1) cv_gstrand[i] = "+";
    if (genes[i].strand == -1) cv_gstrand[i] = "-";
    iv_start_ndx[i]   = genes[i].start_ndx;
    iv_stop_ndx[i]    = genes[i].stop_ndx;
    cv_partial[i]     = genes[i].partial;
    cv_start_type[i]  = genes[i].start_type;
    cv_rbs_motif[i]   = genes[i].rbs_motif;
    cv_rbs_spacer[i]  = genes[i].rbs_spacer;
    nv_GCcont[i]      = genes[i].gc_cont;
    nv_confidence[i]  = genes[i].confidence;
    nv_g_score[i]     = genes[i].score;
    nv_g_cscore[i]    = genes[i].cscore;
    nv_g_sscore[i]    = genes[i].sscore;
    nv_g_rscore[i]    = genes[i].rscore;
    nv_g_uscore[i]    = genes[i].uscore;
    nv_g_tscore[i]    = genes[i].tscore;

//    cv_g_sequence[i]  = genes[i].sequence;

  }

  Rcpp::DataFrame GDF;   // Gene Data Frame

  GDF["identifier"] = cv_identifier;
  GDF["begin"     ] = iv_begin;
  GDF["end"       ] = iv_end;
  GDF["strand"    ] = cv_gstrand;
//GDF["start_ndx" ] = iv_start_ndx;    // These two arrays ...
//GDF["stop_ndx"  ] = iv_stop_ndx;     // ... are NODE indices. Useful for finding information about genes.
  GDF["partial"   ] = cv_partial;
  GDF["start_type"] = cv_start_type;
  GDF["rbs_motif" ] = cv_rbs_motif;
  GDF["rbs_spacer"] = cv_rbs_spacer;
  GDF["gc_cont"   ] = nv_GCcont;
  GDF["confidence"] = nv_confidence;
  GDF["score"     ] = nv_g_score;
  GDF["cscore"    ] = nv_g_cscore;
  GDF["sscore"    ] = nv_g_sscore;
  GDF["rscore"    ] = nv_g_rscore;
  GDF["uscore"    ] = nv_g_uscore;
  GDF["tscore"    ] = nv_g_tscore;

  GDF["sequence"  ] = cv_g_sequence;
  GDF["protein"   ] = cv_p_sequence;

  // Debug statement
  if (0) {
    Rcout << "cv_identifier: " << cv_identifier[0] << std::endl;
    Rcout << "begin        : " << iv_begin[0]      << std::endl;
    Rcout << "end          : " << iv_end[0]        << std::endl;
    Rcout << "strand       : " << cv_gstrand[0]    << std::endl;
    Rcout << "partial      : " << cv_partial[0]    << std::endl;
    Rcout << "start_type   : " << cv_start_type[0] << std::endl;
    Rcout << "rbs_motif    : " << cv_rbs_motif[0]  << std::endl;
    Rcout << "rbs_spacer   : " << cv_rbs_spacer[0] << std::endl;
    Rcout << "gc_cont      : " << nv_GCcont[0]     << std::endl;
    Rcout << "confidence   : " << nv_confidence[0] << std::endl;
    Rcout << "score        : " << nv_g_score[0]    << std::endl;
    Rcout << "cscore       : " << nv_g_cscore[0]   << std::endl;
    Rcout << "sscore       : " << nv_g_sscore[0]   << std::endl;
    Rcout << "rscore       : " << nv_g_rscore[0]   << std::endl;
    Rcout << "uscore       : " << nv_g_uscore[0]   << std::endl;
    Rcout << "tscore       : " << nv_g_tscore[0]   << std::endl;
    Rcout << "sequence     : " << "Gene sequence"  << std::endl;
    Rcout << "protein      : " << "Protein sequence" << std::endl;
  }

  return(GDF);

  
}
