  #include <Rcpp.h> 
  using namespace Rcpp;

  // [[Rcpp::export]]
  DataFrame record_gc_bias_node (IntegerVector gc, DataFrame NDF) {

    // The function to record GC bias in the C implementation is split into two functions:
    //   record_gc_bias_node - to update the node dataframe/class
    //   record_gc_bias_training - to update the training list/class

    // This routine goes through all the ORFs and counts the relative frequency
    // of the most common frame for GC content.  In high GC genomes, this tends to be
    // the third position.  In low GC genomes, this tends to be the first position.
    // Genes will be selected as a training set based on the nature of this bias
    // for this particular organism.

    CharacterVector node_type      = NDF["type"    ];
    IntegerVector   node_ndx       = NDF["ndx"     ];
    CharacterVector node_strand    = NDF["strand"  ];
    IntegerVector   node_stop_val  = NDF["stop_val"];

    int max_fr (int, int, int);

    int i, j, ctr[3][3], last[3], frmod, fr, mfr;

    int nn = node_type.length();

    // Columns to be added to the NODE data frame
    IntegerVector gc_bias(nn);
    NumericMatrix gc_score(nn,3);

    for (i = 0; i < 3; i++)
      for (j = 0; j < 3; j++)
        ctr[i][j] = 0;

    for (i = nn-1; i >= 0; i--) {
      fr = (node_ndx[i])%3; frmod = 3 - fr;

      if (node_strand[i] == "+" && node_type[i] == "STOP") {
        for(j = 0; j < 3; j++)
          ctr[fr][j] = 0;
        last[fr] = node_ndx[i];
        ctr[fr][(gc[node_ndx[i]] + frmod)%3] = 1;
      }
      else if (node_strand[i] == "+") {
        for (j = last[fr]-3; j >= node_ndx[i]; j-=3)
          ctr[fr][(gc[j] + frmod)%3] ++;
        mfr = max_fr(ctr[fr][0], ctr[fr][1], ctr[fr][2]);
        gc_bias[i] = mfr;
        for(j = 0; j < 3; j++) {
          gc_score(i,j) = (3.0*ctr[fr][j]);
          gc_score(i,j) /= (1.0*(node_stop_val[i] - node_ndx[i] + 3));
        }
        last[fr] = node_ndx[i];
      }
    }

    for(i = 0; i < nn; i++) {
      fr = (node_ndx[i])%3; frmod = fr;

      if (node_strand[i] == "-" && node_type[i] == "STOP") {
        for(j = 0; j < 3; j++)
          ctr[fr][j] = 0;
        last[fr] = node_ndx[i];
        ctr[fr][((3-gc[node_ndx[i]]) + frmod)%3] = 1;
      }
      else if (node_strand[i] == "-") {
        for(j = last[fr]+3; j <= node_ndx[i]; j+=3)
          ctr[fr][((3-gc[j]) + frmod)%3]++;
        mfr = max_fr(ctr[fr][0], ctr[fr][1], ctr[fr][2]);
        gc_bias[i] = mfr;
        for(j = 0; j < 3; j++) {
          gc_score(i,j) = (3.0*ctr[fr][j]);
          gc_score(i,j) /= (1.0*(node_ndx[i] - node_stop_val[i] + 3));
        }
        last[fr] = node_ndx[i];
      }
    }


    // Code that appeared here in the original C implementation to update the training list/class
    //   has been moved to the record_gc_bias_training function.


    // Separate the gc_score matrix by columns

    Rcpp::NumericVector gc_score_1(nn);
    Rcpp::NumericVector gc_score_2(nn);
    Rcpp::NumericVector gc_score_3(nn);

    for (i = 0; i < nn; i++) {
      gc_score_1(i) = gc_score(i,0);
      gc_score_2(i) = gc_score(i,1);
      gc_score_3(i) = gc_score(i,2);
    }

    NDF["gc_bias"   ] = gc_bias   ;
    NDF["gc_score_1"] = gc_score_1;
    NDF["gc_score_2"] = gc_score_2;
    NDF["gc_score_3"] = gc_score_3;

    return(NDF);
  }
