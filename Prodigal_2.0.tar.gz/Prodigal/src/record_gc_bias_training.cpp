  #include <Rcpp.h> 
  using namespace Rcpp;

  // [[Rcpp::export]]
  NumericVector record_gc_bias_training (DataFrame NDF, List TL) {

    CharacterVector node_type      = NDF["type"      ];
    IntegerVector   node_ndx       = NDF["ndx"       ];
    IntegerVector   node_stop_val  = NDF["stop_val"  ];
    IntegerVector   gc_bias        = NDF["gc_bias"   ];
    NumericVector   gc_score_1     = NDF["gc_score_1"];
    NumericVector   gc_score_2     = NDF["gc_score_2"];
    NumericVector   gc_score_3     = NDF["gc_score_3"];

    // Note: Node coordinates do not need to be converted to a 0-based system
    //   as in the record_gc_bias routine for nodes
    //   since here they are used only to compute the absolute distance from start to stop

    NumericVector bias = TL["bias"];

    int i, len;

    double tot = 0.0;

    int nn = node_type.length();

    for(i = 0; i < 3; i++)
      bias[i] = 0.0;

    for(i = 0; i < nn; i++) {
      if (node_type[i] != "STOP") {
        len = abs(node_stop_val[i] - node_ndx[i]) + 1;
        if (gc_bias[i] == 0) { bias[0] += (gc_score_1[i] * len)/1000.0; }
        if (gc_bias[i] == 1) { bias[1] += (gc_score_2[i] * len)/1000.0; }
        if (gc_bias[i] == 2) { bias[2] += (gc_score_3[i] * len)/1000.0; }
      }
    }
    tot = bias[0] + bias[1] + bias[2];
    for(i = 0; i < 3; i++)
      bias[i] *= (3.0/tot);

    // TL["bias"] = bias;

    return(bias);
  }
