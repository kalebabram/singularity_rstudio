  #include <Rcpp.h> 
  using namespace Rcpp;

  // [[Rcpp::export]]
  DataFrame record_overlapping_starts(DataFrame NDF, List TL, int flag) {

    CharacterVector node_type       = NDF["type"]      ;
    LogicalVector   node_edge       = NDF["edge"]      ;
    IntegerVector   node_ndx        = NDF["ndx"]       ;
    CharacterVector node_strand     = NDF["strand"]    ;
    IntegerVector   node_stop_val   = NDF["stop_val"]  ;
    IntegerVector   node_star_ptr_1 = NDF["star_ptr_1"];
    IntegerVector   node_star_ptr_2 = NDF["star_ptr_2"];
    IntegerVector   node_star_ptr_3 = NDF["star_ptr_3"];
    NumericVector   node_cscore     = NDF["cscore"]    ;
    NumericVector   node_sscore     = NDF["sscore"]    ;

    const int MAX_SAM_OVLP = 60;  // Number of nucleotide bases permitted in an overlap on the same strand

    double intergenic_mod(DataFrame, List, int, int);

    int nn = node_type.length();

    int i, j, frame;
    double max_sc;

    // Note: The values assigned to start_ptr are node indices in a 0-based numbering system
    // Questions:
    //   * For an R implementation, should the index be incremented for a 1-based numbering system,
    //     or will the indices be used exclusively inside C++ code?  FOR NOW, ***YES*** 1-based ... update 0-based
    //   * Is the ordering of the start_ptr columns important, or can it be considered an unordered set?
    //     Note that column choice is determined by a modulo 3 operation on a genome coordinate.
    //     The original C implementation of Prodigal uses a 0-based coordinate system, the R code, a 1-based coordinate system.

    int start_ptr[nn][3];

    for (i = 0; i < nn; i++) {
      for (j = 0; j < 3; j++) start_ptr[i][j] = -1;
      if (node_type[i] != "STOP" || node_edge[i] == true) continue;
      if (node_strand[i] == "+") {   // forward strand
        max_sc = -100;
        for (j = i+3; j >= 0; j--) {
          if (j >= nn || node_ndx[j] > node_ndx[i]+2) continue;
          if (node_ndx[j] + MAX_SAM_OVLP < node_ndx[i]) break;
          if (node_strand[j] == "+" && node_type[j] != "STOP") {
            if (node_stop_val[j] <= node_ndx[i]) continue;
            frame = (node_ndx[j]) % 3;
            if (flag == 0 && start_ptr[i][frame] == -1)
              // start_ptr[i][frame] = j+1;     // 1-based
              start_ptr[i][frame] = j;          // 0-based

            else if (flag == 1 && (node_cscore[j] + node_sscore[j] + intergenic_mod(NDF, TL, i, j) > max_sc)) {
              frame = (node_ndx[j]) % 3;
              if (frame == 0 ) node_star_ptr_1[i] = j;
              if (frame == 1 ) node_star_ptr_2[i] = j;
              if (frame == 2 ) node_star_ptr_3[i] = j;
              max_sc = node_cscore[j] + node_sscore[j] + intergenic_mod(NDF, TL, i, j);
            }
          }
        }
      }
      else {     // reverse strand
        max_sc = -100;
        for (j = i-3; j < nn; j++) {
          if (j < 0 || node_ndx[j] < node_ndx[i]-2) continue;
          if (node_ndx[j] - MAX_SAM_OVLP > node_ndx[i]) break;
          if (node_strand[j] == "-" && node_type[j] != "STOP") {
            if (node_stop_val[j] >= node_ndx[i]) continue;
            frame = (node_ndx[j]) % 3;
            if (flag == 0 && start_ptr[i][frame] == -1)
              // start_ptr[i][frame] = j+1;     // 1-based
              start_ptr[i][frame] = j;          // 0-based

            else if (flag == 1 && (node_cscore[j] + node_sscore[j] + intergenic_mod(NDF, TL, j, i) > max_sc)) {
              frame = (node_ndx[j]) % 3;
              if (frame == 0 ) node_star_ptr_1[i] = j;
              if (frame == 1 ) node_star_ptr_2[i] = j;
              if (frame == 2 ) node_star_ptr_3[i] = j;
              max_sc = node_cscore[j] + node_sscore[j] + intergenic_mod(NDF, TL, j, i);
            }
          }
        }
      }
    }


    // extract columns from 2D array - very kludgy!

    IntegerVector star_ptr_1(nn);
    IntegerVector star_ptr_2(nn);
    IntegerVector star_ptr_3(nn);

    // Permute to align results with the original C implementation

    for (i = 0; i < nn; i++) {
      star_ptr_1[i] = start_ptr[i][0];
      star_ptr_2[i] = start_ptr[i][1];
      star_ptr_3[i] = start_ptr[i][2];
    }


    NDF["star_ptr_1"] = star_ptr_1;
    NDF["star_ptr_2"] = star_ptr_2;
    NDF["star_ptr_3"] = star_ptr_3;

    return(NDF);
  }
