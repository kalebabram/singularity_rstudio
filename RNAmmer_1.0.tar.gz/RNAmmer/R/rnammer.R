rnammer <- function(seq, dom, mol) {

  # seq - a DNAString, the sequence to search for rRNA
  # dom - domain of life
  # mol - specific rRNA molecule we're searching for

  if      (dom == "ARC") { domain = 0 }  # Archaea
  else if (dom == "BAC") { domain = 1 }  # Bacteria
  else if (dom == "EUK") { domain = 2 }  # Eukarya
  else                   { return (paste(dom, "is an unknown Domain. Choices are 'ARC' for Archaea, 'BAC' for Bacteria, 'EUK' for Eukarya")) }

  if      (mol== "TSU") { rRNA = 0 }   # 5/8s
  else if (mol== "SSU") { rRNA = 1 }   # 16/18s
  else if (mol== "LSU") { rRNA = 2 }   # 23/28s
  else                  { return (paste(mol, "is an unknown Molecule. Choices are 'TSU' for 5/8s, 'SSU' for 16/18s, 'LSU' for 23/28s")) }

  # Flanking regions around the small subunit ribosomal RNA (16S)

  FLANK_BEG_SSU <- 2500
  FLANK_END_SSU <- 2500

  rev <- reverseComplement(seq)

  # return(rev)

  # Find the directory where the RNAmmer HMM files are stored
  #   This is difficult to do from the C++ layer
  # We know the HMM for bacterial 16S will be in this directory

  knownFile <- "bac.ssu.rnammer.hmm"
  hmmDir <- sub(knownFile, "", system.file("extdata", knownFile, package = "RNAmmer"))

  rrna.df <- as.data.frame(hmmAccess(as.character(seq), as.character(rev), domain, rRNA, hmmDir),stringsAsFactors=FALSE)
  rrna.df <- rrna.df[order(-rrna.df$score),]

  return(rrna.df)
  
}
